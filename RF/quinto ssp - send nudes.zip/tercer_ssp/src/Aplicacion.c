/*
 * Aplicacion.c
 *
 *  Created on: 13 de oct. de 2017
 *      Author: fedec
 */

#include "Aplicacion.h"

extern uint32_t resultadoADC;
extern uint8_t entero_ascii[];
extern uint8_t f_refresh_LCD;
extern volatile uint16_t segundos;
extern volatile int aux;

extern volatile uint8_t BuffSSP1[20];
extern volatile uint8_t flags_int_ssp1[4];

extern volatile uint8_t i;
extern volatile uint8_t hello_msg[11];
extern volatile uint8_t *msg_ptr;

volatile uint8_t msg_cad[2]={0,'\0'};

void Aplicacion(void) {




	if(!aux){
		Display (segundos);
		Conversor(segundos);

		if (f_refresh_LCD){

			//DisplayLCD (entero_ascii,1,0);
			SetPIN (RGBB,0);
			SetPIN (RGBG,0);

			if (segundos==2) DisplayLCD("Ready        ",0,0);//msg, renglon, offset

			//Hice esto para tener controlada la salida al LCD (solo refresca cada segundo marcado por flagADC
			if (segundos==3) {
				DisplayLCD ("          ",0,0);
				DisplayLCD ("            ",1,0);

			}
			if (segundos==5) DisplayLCD ("Iniciando      ",0,0);
			if (segundos>=7){

				SendSSP1 (*(msg_ptr+i));
				SetPIN (RGBB,1); //Enciendo LED azul al enviar
				DisplayLCD ("Enviado: ",0,0);//mensaje, renglon, offset
				msg_cad[0]=*(msg_ptr+i);
				DisplayLCD (msg_cad,0,10); //Muestro lo que mandé

				DisplayLCD ("Recibido: ",1,0);
				if (flags_int_ssp1[RXMIS]){

								//SetPIN (RGBG,1); //Enciendo LED verde diciendo que llegó algo
								flags_int_ssp1[RXMIS]=0;
								msg_cad[0]=BuffSSP1[i];
						}

				DisplayLCD (msg_cad,1,11); //Muestro lo que recibí
				i++;
				if (*(msg_ptr+i) == '\0') i=0;
				if (*(msg_ptr+i) =='s') 	SetPIN (RGBG,1);
			}

		}
		f_refresh_LCD = 0;




	}
}
