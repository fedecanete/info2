#include "Aplicacion.h"

extern volatile int DemoraLCD;
extern volatile uint16_t segundos;
extern volatile int aux;
extern uint8_t f_refresh_LCD;

void SysTick_Handler(void) {

	static volatile uint8_t decimas  = DECIMAS;
// Aquí escribo todo aquello que deseo que ocurra cada 2,5ms.

	BarridoDisplay();
	Dato_LCD();
	if ( Demora_LCD )
		Demora_LCD--;


	decimas-- ;
 	if( !decimas )	//pasaron 100ms
	{
		decimas = DECIMAS ;
		// Aquí escribo todo aquello que deseo que ocurra cada 100ms.
		if (GetPIN(LEDXpresso,1))SetPIN(LEDXpresso,0);
		else SetPIN (LEDXpresso,1);
		aux++;
		if (aux==10){
			segundos++;
			f_refresh_LCD = 1;
			aux=0;
			if (segundos==30)segundos=0;
		}
		}

	}


