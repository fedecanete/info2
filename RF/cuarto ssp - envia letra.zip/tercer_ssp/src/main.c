/*
===============================================================================
 Name        : primer_ssp.c
 Author      : $(author)
 Version     :
 Copyright   : $(copyright)
 Description : main definition
===============================================================================
*/

#ifdef __USE_CMSIS
#include "LPC17xx.h"
#endif

#include <cr_section_macros.h>
#include <NXP/crp.h>

// Variable to store CRP value in. Will be placed automatically
// by the linker when "Enable Code Read Protect" selected.
// See crp.h header for more information
//__CRP const unsigned int CRP_WORD = CRP_NO_CRP;

#include "Aplicacion.h"

void Aplicacion (void);

//Buffers Expansión 3 y Teclado
volatile uint8_t msgDisplay[DIGITOS];			//!< Buffer de display
volatile uint8_t BufferEntradas;				//Buffer de Entradas Digitales

//Variables para LCD
volatile int DemoraLCD;
volatile uint16_t segundos=0;
volatile int aux=0;
uint8_t bufferLCD[TOPE_BUFFER_LCD];
uint8_t msg[20];
uint8_t ptrLecturaLCD = 0;
uint8_t ptrEscrituraLCD = 0;
uint8_t entero_ascii[6];
uint8_t f_refresh_LCD = 0;

//Buffers para SSP1
volatile uint8_t BuffSSP1[20];						//!< Buffer de Comunicación SPI
volatile uint8_t flags_int_ssp1[4];				//Flags de interrupciones



int main(void) {

	InicializarKit();
	Display (123456);			/*(1 displays de 6 dígitos)*/

    while (1) {

		Aplicacion();

	}
	return 0;
}
