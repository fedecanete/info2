/*
 * FW_SSP1.c
 *
 *  Created on: 15 de oct. de 2017
 *      Author: Federico
 */
#include "Aplicacion.h"

extern volatile uint8_t BuffSSP1;
extern volatile uint8_t flags_int_ssp1[4];

//La interrupción llega cuando se está llenando el FIFO de recepción
void SSP1_IRQHandler(void){

//Primero determino la causa de la interrupción (aunque ya la sepa en este caso: RXMIS)
	//**** TODOS ESTOS FLAGS SE PONEN EN 1 SI Y SÓLO SI SU INTERRUPCION CORRESPONDIENTE ESTABA HABILITADA******//

	if (SSP1MIS & (1 << RORMIS)) //Receive Overrun. Si se recibió completamente un frame y el Rx FIFO estaba lleno (HUBO SOBREESCRITURA)
		flags_int_ssp1[RORMIS] = 1;

	if (SSP1MIS & (1 << RTMIS)) //Receive Time-Out. El dato estuvo demasiado tiempo en el Rx FIFO
					flags_int_ssp1[RTMIS] = 1;

	if (SSP1MIS & (1 << RXMIS)) //El Rx FIFO está por lo menos medio lleno
					flags_int_ssp1[RXMIS] = 1;

	if (SSP1MIS & (1 << TXMIS)) //El Tx FIFO está por lo menos medio vacío
		flags_int_ssp1[TXMIS] = 1;

	BuffSSP1 = SSP1DR; //Guardo el dato (aunque no sé si terminó de llegar) SE PUEDE ARREGLAR CON BSY
}
