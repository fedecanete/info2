/*
 * Aplicacion.c
 *
 *  Created on: 13 de oct. de 2017
 *      Author: fedec
 */

#include "Aplicacion.h"

extern uint32_t resultadoADC;
extern uint8_t entero_ascii[];
extern uint8_t f_refresh_LCD;
extern volatile uint16_t segundos;
extern volatile int aux;

extern volatile uint8_t BuffSSP1;
extern volatile uint8_t flags_int_ssp1[4];

volatile uint8_t msg_cad[2]={0,'\0'};
void Aplicacion(void) {




	if(!aux){
		Display (segundos);
		Conversor(segundos);

		if (f_refresh_LCD){

			//DisplayLCD (entero_ascii,1,0);
			if (!segundos) DisplayLCD("Ready",0,0);//msg, renglon, offset

			//Hice esto para tener controlada la salida al LCD (solo refresca cada segundo marcado por flagADC
			if (segundos==1) {
				DisplayLCD ("          ",0,0);
				DisplayLCD ("            ",1,0);

			}
			if (segundos==5) DisplayLCD ("Iniciando   ",0,0);
			if (segundos==7){
				DisplayLCD ("Enviado: A  ",1,0);//mensaje, renglon, offset
				SendSSP1 ('A');
				SetPIN (RGBB,1); //Enciendo LED azul al enviar
			}
			if (segundos==8)SetPIN (RGBB,0);
			if (segundos==10){
				SetPIN (RGBB,0);
				DisplayLCD ("Enviado: A",0,0);
				DisplayLCD ("Recibido: ",1,0);
				if (flags_int_ssp1[RXMIS]){

					SetPIN (RGBG,1); //Enciendo LED verde diciendo que llegó algo
					msg_cad[0]=BuffSSP1;
					flags_int_ssp1[RXMIS]=0;

				}

			}
			if (segundos==12) {
				DisplayLCD (msg_cad,1,11);
				SetPIN (RGBG,0);
			}
		}
		f_refresh_LCD = 0;
	}
}
