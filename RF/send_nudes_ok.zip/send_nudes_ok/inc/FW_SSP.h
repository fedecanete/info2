/*
 * FW_SPP.h
 *
 *  Created on: 13 de oct. de 2017
 *      Author: fedec
 */

#ifndef FW_SSP_H_
#define FW_SSP_H_

#include "Aplicacion.h"

#define SSP1_ON PCONP|=1<<PCSSP1
#define EMPTY 0
#define SENT 1
#define SEND_DENIED -1

#define START_TRANSMISSION SSP1DR=Buff_Tx_SSP1[SSP1_TxOut_Idx]


void Inicializar_SSP1 (void);
//Firmware
void WriteRx (uint8_t);
int SendSSP1 (void);
uint8_t ReadTx (void);
//Primitivas
void WriteTx (uint8_t);
uint8_t ReadRx (void);

#endif /* FW_SSP_H_ */
