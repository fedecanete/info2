/*
 * Aplicacion.c
 *
 *  Created on: 13 de oct. de 2017
 *      Author: fedec
 */

#include "Aplicacion.h"
#include "FW_SSP.h"

extern uint32_t resultadoADC;
extern uint8_t entero_ascii[];
extern uint8_t f_refresh_LCD;
extern volatile uint16_t segundos;
extern volatile int aux;

extern volatile uint8_t Buff_Tx_SSP1[TOPE_SSP1];
extern volatile uint8_t Buff_Rx_SSP1[TOPE_SSP1];		//!< Buffer de Recepción SPI
extern volatile uint8_t flags_int_ssp1[4];				//Flags de interrupciones
extern volatile uint8_t SSP1_RxIn_Idx;				//Índices para el manejo de los buffers
extern volatile uint8_t SSP1_RxOut_Idx;
extern volatile uint8_t SSP1_TxIn_Idx;
extern volatile uint8_t SSP1_TxOut_Idx;


volatile uint8_t hello_msg[]="send nudes";
volatile uint8_t *msg_ptr=hello_msg;

volatile uint8_t msg_cad[2]={0,'\0'};
volatile uint8_t send_enable=1, r_enable;
volatile uint8_t full_word=0, llenar_buffer=1;;

void Aplicacion(void) {

		uint8_t i=0;
		Display (segundos);
		Conversor(segundos);
		if (f_refresh_LCD){


			//DisplayLCD (entero_ascii,1,0);
			SetPIN (RGBB,0);
			SetPIN (RGBG,0);

			if (segundos==2) {
				DisplayLCD("Ready           ",0,0);//msg, renglon, offset
				DisplayLCD ("               ",1,0);

			}

			//Hice esto para tener controlada la salida al LCD (solo refresca cada segundo marcado por flagADC
			if (segundos==3) {
				DisplayLCD ("               ",0,0);

			}
			if (segundos==4) DisplayLCD ("Iniciando      ",0,0);

			if (segundos ==5){

				DisplayLCD ("Tx: ",0,0);//mensaje, renglon, offset
				DisplayLCD ("Rx: ",1,0);

			}

			if (segundos>=5){

				//Lleno el buffer de transmisión y muestro lo que preparo para enviar
				//(eventualy se enviará)
				if (llenar_buffer){


					for (i=0;*(msg_ptr+i)!= '\0'; i++) {

										WriteTx (*(msg_ptr+i));
										msg_cad[0]=*(msg_ptr+i);
										DisplayLCD (msg_cad,0,4+i); //Muestro lo que mandé

									}

                     llenar_buffer=0;

				}


				if (full_word){ //pregunto si terminó de completarse la recepción y el llenado del buffer rx

					full_word=0;
					SetPIN (RGBG,1); //Indico con LED verde el fin de recepción
					SetPIN (RGBB,0);
					for (i=0; *(msg_ptr+i)!= '\0'; i++) {

						msg_cad[0]=ReadRx();
						DisplayLCD (msg_cad,1,4+i); //Muestro lo que recibí
					}
					llenar_buffer=1;

				}

			}

		}
		f_refresh_LCD = 0;





}
