/*
 * FW_SSP1.c
 *
 *  Created on: 15 de oct. de 2017
 *      Author: Federico
 */
#include "Aplicacion.h"
#include "FW_SSP.h"

extern volatile uint8_t Buff_Tx_SSP1[TOPE_SSP1];		//!< Buffer de Transmisión SPI
extern volatile uint8_t Buff_Rx_SSP1[TOPE_SSP1];		//!< Buffer de Recepción SPI
extern volatile uint8_t flags_int_ssp1[4];				//Flags de interrupciones
extern volatile uint8_t SSP1_RxIn_Idx;				//Índices para el manejo de los buffers
extern volatile uint8_t SSP1_RxOut_Idx;
extern volatile uint8_t SSP1_TxIn_Idx;
extern volatile uint8_t SSP1_TxOut_Idx;

extern volatile uint8_t send_enable;



//La interrupción llega cuando se está llenando el FIFO de recepción
void SSP1_IRQHandler(void){

	uint8_t copia=0;

//Primero determino la causa de la interrupción (aunque ya la sepa en este caso: RXMIS)
	//**** TODOS ESTOS FLAGS SE PONEN EN 1 SI Y SÓLO SI SU INTERRUPCION CORRESPONDIENTE ESTABA HABILITADA******//

	if (SSP1MIS & (1 << RORMIS)) //Receive Overrun. Si se recibió completamente un frame y el Rx FIFO estaba lleno (HUBO SOBREESCRITURA)
		flags_int_ssp1[RORMIS] = 1;

	if (SSP1MIS & (1 << RTMIS)){ //Receive Time-Out. El dato estuvo demasiado tiempo en el Rx FIFO

		flags_int_ssp1[RTMIS] = 1;
		SSP1ICR |= (1 << RTIC); //Clear the interrupt condition
	}

	if (SSP1MIS & (1 << RXMIS)) //El Rx FIFO está por lo menos medio lleno
					flags_int_ssp1[RXMIS] = 1;

	if (SSP1MIS & (1 << TXMIS)) //El Tx FIFO está por lo menos medio vacío
		flags_int_ssp1[TXMIS] = 1;

	//while (SSP1SR & (1 << BSY));
	if (SSP1SR & (1 << RNE)){

			copia=SSP1DR;
			WriteRx(copia); //Guardo el dato en el buffer de recepción(me aseguré que no está ocupado el módulo)
			//r_enable=1;
			send_enable=1;
	}

}

int SendSSP1 (void)
{
	int aux;
	//Primero se fija que haya dato
	aux = (int)ReadTx();
	if (aux>0 && send_enable){ //Si hay dato y puedo enviar, envío
		//Al escribir en el registro DR (SSP1DR) se inicia automáticamente el proceso de envío.
		//while (SSP)
		SSP1DR = aux;
		send_enable=0;
		return SENT;
	}

	//Si llego acá es que o no hay dato o no se puede enviar
	if (!send_enable) return SEND_DENIED;
	else return EMPTY; //Aviso que está todo OK ****AUNQUE NO SE HAYA ENVIADO NADA*****

/*
	while (SSP1SR & (1 << BSY)); //Se queda esperando a que BSY = 0
	//Al salir los datos ya se enviaron y hay otros datos (recibidos) en el registro DR

	//Guardo los datos recibidos
	BuffSSP1 = SSP1DR;
*/

}

uint8_t ReadTx (void)
{
	uint8_t aux = 0; //Retorna 0 cuando no hay dato que trasmitir
	if (SSP1_TxIn_Idx != SSP1_TxOut_Idx){

		aux = Buff_Tx_SSP1[SSP1_TxOut_Idx];
		SSP1_TxOut_Idx++;
		SSP1_TxOut_Idx%=TOPE_SSP1;

	}
	return aux;

}

void WriteRx (uint8_t dato)
{
	Buff_Rx_SSP1[SSP1_RxOut_Idx] = dato;
	SSP1_RxOut_Idx++;
	SSP1_RxOut_Idx %= TOPE_SSP1;
}

