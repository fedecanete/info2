/*
 * PR_SSP1.c
 *
 *  Created on: 14 de oct. de 2017
 *      Author: Federico
 */
#include "ssp.h"
#include "FW_SSP.h"
extern volatile uint8_t Buff_Tx_SSP1[TOPE_SSP1];
extern volatile uint8_t Buff_Rx_SSP1[TOPE_SSP1];		//!< Buffer de Recepción SPI
extern volatile uint8_t flags_int_ssp1[4];				//Flags de interrupciones
extern volatile uint8_t SSP1_RxIn_Idx;				//Índices para el manejo de los buffers
extern volatile uint8_t SSP1_RxOut_Idx;
extern volatile uint8_t SSP1_TxIn_Idx;
extern volatile uint8_t SSP1_TxOut_Idx;

extern volatile uint8_t send_enable; //Flag que habilita la transmisión


// primitiva que escribe en el buffer de Tx (BufferTx), verificando TOPE e ini-
// ciando la Tx si no hay
// transmisión en curso.

void WriteTx (uint8_t dato)
{
	Buff_Tx_SSP1[SSP1_TxIn_Idx]=dato;
	SSP1_TxIn_Idx++;
	SSP1_TxIn_Idx%=TOPE_SSP1;


}

uint8_t ReadRx (void)
{
	uint8_t dato= Buff_Rx_SSP1[SSP1_RxIn_Idx];
	SSP1_RxIn_Idx++;
	SSP1_RxIn_Idx%=TOPE_SSP1;
	return dato;
}
