/*
 * FW_SSP1.c
 *
 *  Created on: 15 de oct. de 2017
 *      Author: Federico
 */
#include "Aplicacion.h"
#include "FW_SSP.h"

extern volatile uint8_t Buff_Tx_SSP1[TOPE_SSP1];		//!< Buffer de Transmisión SPI
extern volatile uint8_t Buff_Rx_SSP1[TOPE_SSP1];		//!< Buffer de Recepción SPI
extern volatile uint8_t flags_int_ssp1[4];				//Flags de interrupciones
extern volatile uint8_t SSP1_RxIn_Idx;				//Índices para el manejo de los buffers
extern volatile uint8_t SSP1_RxOut_Idx;
extern volatile uint8_t SSP1_TxIn_Idx;
extern volatile uint8_t SSP1_TxOut_Idx;

extern volatile uint8_t send_enable;
extern volatile uint8_t veces;

volatile uint32_t interrupciones=0;
volatile uint8_t rx_h_full=0;
volatile uint8_t tx_h_empty=0;

void flags_SSP (void);

//La interrupción llega cuando se está llenando el FIFO de recepción
void SSP1_IRQHandler(void){

	uint8_t copia=0;

//Primero determino la causa de la interrupción (aunque ya la sepa en este caso: RXMIS)
	//**** TODOS ESTOS FLAGS SE PONEN EN 1 SI Y SÓLO SI SU INTERRUPCION CORRESPONDIENTE ESTABA HABILITADA******//

	if (SSP1MIS & (1 << RORMIS)) //Receive Overrun. Si se recibió completamente un frame y el Rx FIFO estaba lleno (HUBO SOBREESCRITURA)
		flags_int_ssp1[RORMIS] = 1;

	if (SSP1MIS & (1 << RTMIS)){ //Receive Time-Out. El dato estuvo demasiado tiempo en el Rx FIFO

		flags_int_ssp1[RTMIS] = 1;
		SSP1ICR |= (1 << RTIC); //Clear the interrupt condition
	}


	if (SSP1MIS & (1 << TXMIS)) //El Tx FIFO está por lo menos medio vacío
		tx_h_empty = 1;
	else tx_h_empty =0;

	if (SSP1MIS & (1 << RXMIS)){//El Rx FIFO está por lo menos medio lleno
		rx_h_full=1;
		do{
			while (SSP1SR & (1 << BSY));
			Buff_Rx_SSP1[veces]=SSP1DR;
			//flags_SSP();
			veces++;
			veces%=TOPE_SSP1;
		}while (SSP1SR & (1 << RNE)); //Mientras me diga que está no vacío




	}
	else rx_h_full=0;


			//copia=SSP1DR;
		//	WriteRx(copia); //Guardo el dato en el buffer de recepción(me aseguré que no está ocupado el módulo)
			//r_enable=1;
			send_enable=1;
	interrupciones++;

}

uint8_t SendSSP1 (void)
{
	//Primero se fija que haya dato
	//(Si los índices son iguales quiere decir que no se escribieron datos)
	if (SSP1_TxIn_Idx != SSP1_TxOut_Idx){

		//Debe esperar a que el periférico se desocupe y además el Tx FIFO no esté lleno
			while (SSP1SR & (1<<BSY) || !(SSP1SR & (1<<TNF)));
		//Al escribir en el registro DR (SSP1DR) se inicia automáticamente el proceso de envío.
			SSP1DR = Buff_Tx_SSP1[SSP1_TxOut_Idx];
		//Control de índices
			SSP1_TxOut_Idx++;
			SSP1_TxOut_Idx%=TOPE_SSP1;
		//Espera a que se termine de enviar
			while (SSP1SR & (1<<BSY));
			return SENT;

	} else return EMPTY;
	//La funcion anterior incorporaba un send enable para hablar con el main y el systick
	//if (!send_enable) return SEND_DENIED;

}

void WriteRx (uint8_t dato)
{

	do{
	//Espera a que el módulo se desocupe (BSY='0')
		while (SSP1SR & (1 << BSY));
		Buff_Rx_SSP1[SSP1_RxOut_Idx] = SSP1DR;
		SSP1_RxOut_Idx++;
		SSP1_RxOut_Idx %= TOPE_SSP1;
	}while (SSP1SR & (1 << RNE)); //Mientras me diga que está no vacío

}
void flags_SSP (void)
{
	if (SSP1SR & (1 << TFE))
			flags_int_ssp1[TFE] = 1;
	else flags_int_ssp1[TFE] = 0;

	if (SSP1SR & (1 << TNF))
			flags_int_ssp1[TNF] = 1;
	else flags_int_ssp1[TNF] = 0;

	if (SSP1SR & (1 << RNE))
		flags_int_ssp1[RNE] = 1;
	else flags_int_ssp1[RNE] = 0;

	if (SSP1SR & (1 << RFF))
		flags_int_ssp1[RFF] = 1;
	else flags_int_ssp1[RFF] = 0;


}
