/*
===============================================================================
 Name        : sapo.c
 Author      : $(author)
 Version     :
 Copyright   : $(copyright)
 Description : main definition
===============================================================================
*/

#ifdef __USE_CMSIS
#include "LPC17xx.h"
#endif

#include <cr_section_macros.h>
#include <NXP/crp.h>
/**
 * 03-11-17
 * ESTE PROGRAMA prueba el módulo SSP1 por interrupciones
 *
 * Los principales inconvenientes que trae este modulo son que:
 *
 * NINGÚN REGISTRO OBEDECE AL VALOR AFTER RESET QUE INDICA EL MANUAL
 * Por profilaxis conviene forzar valores conocidos
 *
 * CONVIENE VACIAR con "Dummy" El FIFO de recepcion asi no crea interrupciones al inicializar
 * (siempre tiene basura en el y hace que se active RNE)
 *
 * Cuando se escribe de una (un for) el FIFO de transmisión, llega la interrupción
 * de recepción (Rx FIFO not empty ='1') PERO puede ser que no se hayan
 * transmitido TODOS los datos en el Tx FIFO y esa interrupción no haya podido vaciarlo correctamente
 * Es decir, faltan transmitir o llegar datos pero todavía no se dio la interrupcion y puede que no se dé.
 * Y si encima el dato restante no "llena hasta la mitad" el RX FIFO entonces no habrá interrupción
 * y al dato habrá que irlo a buscar a través de una llamada a función.
 *
 * TENER en cuenta CUANDO se puede leer y CUANDO se puede escribir en el SSP1DR (ver manual, tiene que ver con los bits TNF y RNE)
 *
 * LAS interrupciones conviene activarlas solo cuando comiencen a necesitarse (ej, después de transmitir)
 * porque ocurren demasiada cantidad de ellas (como 6 millones, literal) incluso antes de que se llegue a ejecutar Aplicacion()
 *
 * ESTE PROGRAMA manda una cadena de cinco digitos y la guarda en el buffer de recepcion
 * AUN no se probó qué pasa si se sobrepasa la cantidad de datos a escribir el Tx FIFO (>8)
 *
 */;

#include "Aplicacion.h"

void Aplicacion (void);

//Buffers Expansión 3 y Teclado
volatile uint8_t msgDisplay[DIGITOS];			//!< Buffer de display
volatile uint8_t BufferEntradas;				//Buffer de Entradas Digitales

//Variables para LCD
volatile int DemoraLCD;
volatile uint16_t segundos=0;
volatile int aux=0;
uint8_t bufferLCD[TOPE_BUFFER_LCD];
uint8_t msg[20];
uint8_t ptrLecturaLCD = 0;
uint8_t ptrEscrituraLCD = 0;
uint8_t entero_ascii[6];
uint8_t f_refresh_LCD = 0;

//Buffers para SSP1

volatile uint8_t Buff_Tx_SSP1[TOPE_SSP1];		//!< Buffer de Transmisión SPI
volatile uint8_t Buff_Rx_SSP1[TOPE_SSP1];		//!< Buffer de Recepción SPI
volatile uint8_t flags_int_ssp1[4];				//Flags de interrupciones
volatile uint8_t SSP1_RxIn_Idx = 0;				//Índices para el manejo de los buffers
volatile uint8_t SSP1_RxOut_Idx = 0;
volatile uint8_t SSP1_TxIn_Idx = 0;
volatile uint8_t SSP1_TxOut_Idx = 0;



int main(void) {

	InicializarKit();
	Display (123456);			/*(1 displays de 6 dígitos)*/

    while (1) {

		Aplicacion();

	}
	return 0;
}
