/*
 * Aplicacion.h
 *
 *  Created on: 07/09/2013
 *      Author: marcelo
 */

#ifndef APLICACION_H_
#define APLICACION_H_

#include "FW_Display_Exp3.h"
#include "FW_GPIO.h"
#include "KitInfo2_BaseBoard.h"
#include "Oscilador.h"
#include "RegsLPC1769.h"
#include "Teclado_4x1.h"
#include "Entradas.h"
#include "lcd.h"
#include "Timers.h"

void InicializarKit(void);
uint8_t Teclado( void );

#endif /* APLICACION_H_ */
