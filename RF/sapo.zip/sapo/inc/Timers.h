#ifndef TIMERS_H_
#define TIMERS_H_

//	#include "Regs.h"

	#define			TIMERS			8

	#define			LIMPIObANDERA	Eventos &= ~i

	// --- Eventos
	#define			EVENTO0		0	//Evento cada 1 décima de seg
	#define			EVENTO1		1	//Evento cada 1 segundo
	#define			EVENTO2		2	//Evento cada 5 segundos

	// --- Tiempos
	#define			T0			1
	#define			T1			10
	#define			T2			50

#define DECIMAS		40		//la cuenta es para ticks de2,5ms.

// --- prototipo de funciones
	void TmrStart(uint8_t ,uint8_t);
	void TmrClose(void);
	void TmrStop(uint8_t );
	void AnalizarTimer(void);
	void TmrEvent(void);

#endif
