/*
 * Aplicacion.c
 *
 *  Created on: 13 de oct. de 2017
 *      Author: fedec
 */

#include "Aplicacion.h"

extern uint32_t resultadoADC;
extern uint8_t entero_ascii[];
extern uint8_t f_refresh_LCD;
extern volatile uint16_t segundos;
extern volatile int aux;

extern volatile uint8_t BuffSSP1[6];
extern volatile uint8_t flags_int_ssp1[4];

extern volatile uint8_t i;
extern volatile uint8_t hello_msg[5];
extern volatile uint8_t *msg_ptr;

volatile uint8_t msg_cad[2]={0,'\0'};
volatile uint8_t w_enable, r_enable;

void Aplicacion(void) {

		Display (segundos);
		Conversor(segundos);
		if (f_refresh_LCD){


			//DisplayLCD (entero_ascii,1,0);
			SetPIN (RGBB,0);
			SetPIN (RGBG,0);

			if (segundos==2) DisplayLCD("Ready        ",0,0);//msg, renglon, offset

			//Hice esto para tener controlada la salida al LCD (solo refresca cada segundo marcado por flagADC
			if (segundos==3) {
				DisplayLCD ("               ",0,0);
				DisplayLCD ("               ",1,0);
				i=0;
				w_enable=1;

			}
			if (segundos==4) DisplayLCD ("Iniciando      ",0,0);

			if (segundos ==5){

				DisplayLCD ("Enviado: ",0,0);//mensaje, renglon, offset
				DisplayLCD ("Recibido: ",1,0);

			}

			if (segundos>=5){

				if (i<4) {

					if (w_enable){
						w_enable=0;
						SendSSP1 (*(msg_ptr+i));
						SetPIN (RGBB,1); //Al enviar se ve en azul
						msg_cad[0]=*(msg_ptr+i);
						DisplayLCD (msg_cad,0,10+i); //Muestro lo que mandé

					}
					if (r_enable){

						r_enable=0;
						msg_cad[0]=BuffSSP1[i];
						DisplayLCD (msg_cad,1,10+i); //Muestro lo que recibí
						i++;
					}



				}
				if (i==4){
					SetPIN (RGBG,1); //Enciendo LED verde al terminar el envío
					SetPIN (RGBB,0);
					i=0;
				}

			}

		}
		f_refresh_LCD = 0;





}
