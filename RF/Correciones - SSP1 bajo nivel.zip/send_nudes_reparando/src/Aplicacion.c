/*
 * Aplicacion.c
 *
 *  Created on: 13 de oct. de 2017
 *      Author: fedec
 */

#include "Aplicacion.h"
#include "FW_SSP.h"

extern uint32_t resultadoADC;
extern uint8_t entero_ascii[];
extern uint8_t f_refresh_LCD;
extern volatile uint16_t segundos;
extern volatile int aux;

extern volatile uint8_t Buff_Tx_SSP1[TOPE_SSP1];
extern volatile uint8_t Buff_Rx_SSP1[TOPE_SSP1];		//!< Buffer de Recepción SPI
extern volatile uint8_t flags_int_ssp1[4];				//Flags de interrupciones
extern volatile uint8_t SSP1_RxIn_Idx;				//Índices para el manejo de los buffers
extern volatile uint8_t SSP1_RxOut_Idx;
extern volatile uint8_t SSP1_TxIn_Idx;
extern volatile uint8_t SSP1_TxOut_Idx;
extern volatile uint32_t interrupciones;


volatile uint8_t hello_msg[]="abcdefghij";
volatile uint8_t *msg_ptr=hello_msg;
volatile uint8_t veces=0, extras=0;

volatile uint8_t msg_cad[2]={0,'\0'};
volatile uint8_t send_enable=1, r_enable;
volatile uint8_t full_word=0, llenar_buffer=1;;

void Aplicacion(void) {

		uint8_t i=0;
		Display (segundos);
		Conversor(segundos);
//		if (f_refresh_LCD){
//
//
//			//DisplayLCD (entero_ascii,1,0);
//			SetPIN (RGBB,0);
//			SetPIN (RGBG,0);
//
//			if (segundos==2) {
//				DisplayLCD("Ready           ",0,0);//msg, renglon, offset
//				DisplayLCD ("               ",1,0);
//
//			}
//
//			//Hice esto para tener controlada la salida al LCD (solo refresca cada segundo marcado por flagADC
//			if (segundos==3) {
//				DisplayLCD ("               ",0,0);
//
//			}
//			if (segundos==4) DisplayLCD ("Iniciando      ",0,0);
//
//			if (segundos ==5){
//
//				DisplayLCD ("Tx: ",0,0);//mensaje, renglon, offset
//				DisplayLCD ("Rx: ",1,0);
//
//			}
//
//			if (segundos>=5){
//
//				//Lleno el buffer de transmisión y muestro lo que preparo para enviar
//				//(eventualy se enviará)
//				if (llenar_buffer){
//
//
//					for (i=0;*(msg_ptr+i)!= '\0'; i++) {
//
//										WriteTx (*(msg_ptr+i));
//										msg_cad[0]=*(msg_ptr+i);
//										DisplayLCD (msg_cad,0,4+i); //Muestro lo que mandé
//
//									}
//
//                     llenar_buffer=0;
//
//				}
//
//
//				if (full_word){ //pregunto si terminó de completarse la recepción y el llenado del buffer rx
//
//					full_word=0;
//					SetPIN (RGBG,1); //Indico con LED verde el fin de recepción
//					SetPIN (RGBB,0);
//					for (i=0; *(msg_ptr+i)!= '\0'; i++) {
//
//						msg_cad[0]=ReadRx();
//						DisplayLCD (msg_cad,1,4+i); //Muestro lo que recibí
//					}
//					llenar_buffer=1;
//
//				}
//
//			}
//
//		}
		f_refresh_LCD = 0;
		flags_SSP();
		ISER0 |= (1 << ISE_SSP1);
		if (!flags_int_ssp1[2]){
			for (i=0;i<5; i++){
				while (!(SSP1SR & (1 << TNF)));
				SSP1DR= *(msg_ptr+i);
				flags_SSP();
				//demora para que lleguen los datos
				while (SSP1SR & (1 << BSY));

			}
		}
//Al salir de la transmisión:
		flags_SSP();



		flags_SSP();
		//Que pasa si vuelvo a leer
		//Buff_Rx_SSP1[veces]=SSP1DR;


		//for (i=0;i<12; i++)Buff_Rx_SSP1[i]=0;
		flags_SSP();
		//Que pasa si vuelvo a leer
//		Buff_Rx_SSP1[veces]=SSP1DR;
//		veces++;
//		veces%=TOPE_SSP1;
//		Buff_Rx_SSP1[veces]=SSP1DR;
//		veces++;
//		veces%=TOPE_SSP1;
//		Buff_Rx_SSP1[veces]=SSP1DR;
		//A VECES LA INTERRUPCION NO TERMINA DE VACIAR EL RX FIFO
		do{
					while (SSP1SR & (1 << BSY));
					Buff_Rx_SSP1[veces]=SSP1DR;
					extras++;
					veces++;
					veces%=TOPE_SSP1;
				}while (SSP1SR & (1 << RNE)); //Mientras me diga que está no vacío

		flags_SSP();
		interrupciones=0;
		extras=0;
		for (i=0;i<12; i++)Buff_Rx_SSP1[i]=0;



}
