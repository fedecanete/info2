/*
 * PR_SSP1.c
 *
 *  Created on: 14 de oct. de 2017
 *      Author: Federico
 */
#include "ssp.h"

extern volatile uint8_t BuffSSP1;


void SendSSP1 (uint8_t msg)
{
	//Al escribir en el registro DR (SSP1DR) se inicia automáticamente el proceso de envío.
	SSP1DR = msg;

	while (SSP1SR & (1 << BSY)); //Se queda esperando a que BSY = 0
	//Al salir los datos ya se enviaron y hay otros datos (recibidos) en el registro DR

	//Guardo los datos recibidos
	BuffSSP1 = SSP1DR;


}
