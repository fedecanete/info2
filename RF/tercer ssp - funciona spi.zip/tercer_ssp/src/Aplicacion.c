/*
 * Aplicacion.c
 *
 *  Created on: 13 de oct. de 2017
 *      Author: fedec
 */

#include "Aplicacion.h"

extern uint32_t resultadoADC;
extern uint8_t entero_ascii[];
extern uint8_t flagMuestraADC;
extern volatile uint16_t segundos;
extern volatile int aux;

extern volatile uint8_t BuffSSP1;

volatile uint8_t msg_cad[2]={0,'\0'};
void aplicacionADC(void) {
	uint8_t tecla;

	//TmrEvent();



	if(!aux){
		Display (segundos);
		Conversor(segundos);

		if (flagMuestraADC){

			//DisplayLCD (entero_ascii,1,0);

			//Hice esto para tener controlada la salida al LCD (solo refresca cada segundo marcado por flagADC
			if (segundos==5) DisplayLCD ("          ",0,0);
			if (segundos==7) DisplayLCD ("Iniciando   ",0,0);
			if (segundos==10){
				DisplayLCD ("Enviado: Z",1,0);//mensaje, renglon, offset
				SendSSP1 ('Z');
			}
			if (segundos==15){

				DisplayLCD ("Enviado: Z",0,0);
				DisplayLCD ("Recibido: ",1,0);
				msg_cad[0]=BuffSSP1;
			}
			if (segundos==16) DisplayLCD (msg_cad,1,10);
		}
		flagMuestraADC = 0;
	}
}

	/*
	tecla = Teclado();
	if(tecla != NO_KEY){
		Display (tecla%1000, DSP1); // Muestra tecla en dsilpay 1 (rojo)
		tecla = NO_KEY;
	}

	if(PUERTA_ABIERTA)
		Display(001,DSP0);
	if(PB)
		Display(002,DSP0);
	if(P1)
		Display(003,DSP0);
	if(P12)
		Display(004,DSP0);
	if(P2)
		Display(005,DSP0);

}*/

