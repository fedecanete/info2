/*
 * FW_SPP.h
 *
 *  Created on: 13 de oct. de 2017
 *      Author: fedec
 */

#ifndef FW_SSP_H_
#define FW_SSP_H_

#include "Aplicacion.h"

#define SSP1_ON PCONP|=1<<PCSSP1

void Inicializar_SSP1 (void);
void SendSSP1 (uint8_t);


#endif /* FW_SSP_H_ */
