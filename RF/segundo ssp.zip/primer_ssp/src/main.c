/*
===============================================================================
 Name        : primer_ssp.c
 Author      : $(author)
 Version     :
 Copyright   : $(copyright)
 Description : main definition
===============================================================================
*/

#ifdef __USE_CMSIS
#include "LPC17xx.h"
#endif

#include <cr_section_macros.h>
#include <NXP/crp.h>

// Variable to store CRP value in. Will be placed automatically
// by the linker when "Enable Code Read Protect" selected.
// See crp.h header for more information
//__CRP const unsigned int CRP_WORD = CRP_NO_CRP;

#include "Aplicacion.h"
volatile uint8_t buffKey;						//Buffer de teclado
volatile uint8_t msgDisplay[DIGITOS];			//!< Buffer de display
volatile uint8_t BufferEntradas;				//Buffer de Entradas Digitales
volatile int DemoraLCD;
volatile uint16_t segundos=0;
volatile int aux=0;
uint8_t bufferLCD[TOPE_BUFFER_LCD];
uint8_t msg[20];
uint8_t ptrLecturaLCD = 0;
uint8_t ptrEscrituraLCD = 0;
volatile uint8_t TmrRun[];
volatile uint8_t Eventos;
uint8_t led_lpc = 0;
uint32_t resultadoADC = 0;
uint8_t entero_ascii[6];
uint8_t flagMuestraADC = 0;

int main(void) {

	InicializarKit();
	TmrStart(EVENTO0, T1);		//arranco la temporización
	//Display (000, DSP0);		/*(2 displays de 3 dígitos)*/
	//Display (000, DSP1);		/*(2 displays de 3 dígitos)*/

	Display (123456);			/*(1 displays de 6 dígitos)*/

    DisplayLCD("Data to send:",0,1);//msg, renglon, offset




	while (1) {


		aplicacionADC();
	}
	return 0;
}
