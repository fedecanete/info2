/*
 * FW_InitSSP.c
 *
 *  Created on: 13 de oct. de 2017
 *      Author: fedec
 */

#include "Aplicacion.h"
#include "FW_SSP.h"
void Inicializar_SSP1 (void){

	//1.- Activo la alimentacion del dispositivo desde el registro PCONP:
	SSP1_ON;

	//2.- Selecciono el clock como 25MHz (00: CCLK/4)
	PCLKSEL0 &= ~(3 << PCLK_SSP1);
	PCLKSEL0 |= (00<< PCLK_SSP1);

	//3.- Pines: Todos en función "10"
	SetPINSEL (MOSI1,2);
	SetPINSEL (MISO1,2);
	SetPINSEL (SCK1,2);
	SetPINSEL (SSEL1,2);

}
