/*
 * Aplicacion.c
 *
 *  Created on: 13 de oct. de 2017
 *      Author: fedec
 */

#include "Aplicacion.h"

extern uint32_t resultadoADC;
extern uint8_t entero_ascii[];
extern uint8_t flagMuestraADC;
extern volatile uint16_t segundos;
extern volatile int aux;

void aplicacionADC(void) {
	uint8_t tecla;

	//TmrEvent();



	if(!aux){
		Display (segundos);
		Conversor(segundos);

		if (flagMuestraADC){

			DisplayLCD (entero_ascii,1,0);
			//Hice esto para tener controlada la salida al LCD
			/*if (segundos==5) DisplayLCD ("A",1,6);// mensaje,renglon,offset
			if (segundos==10) DisplayLCD ("B",1,6);*/
			flagMuestraADC = 0;
		}
	}

	/*
	tecla = Teclado();
	if(tecla != NO_KEY){
		Display (tecla%1000, DSP1); // Muestra tecla en dsilpay 1 (rojo)
		tecla = NO_KEY;
	}

	if(PUERTA_ABIERTA)
		Display(001,DSP0);
	if(PB)
		Display(002,DSP0);
	if(P1)
		Display(003,DSP0);
	if(P12)
		Display(004,DSP0);
	if(P2)
		Display(005,DSP0);
*/
}

