#include "Aplicacion.h"

extern volatile int DemoraLCD;
extern volatile uint16_t contador;

void SysTick_Handler(void) {

	Dato_LCD();
	if ( Demora_LCD )
		Demora_LCD--;

}
