#include "Aplicacion.h"

void Inicializacion(){
	InicPLL();
	InicSysTick();
	RTC_init();
	InitLCD();
}

//-----------------------------------------------------------------------------
// Configuración del SysTick para 10ms
//-----------------------------------------------------------------------------
void InicSysTick(void) { //si divido x 4, interrumpe cada 2,5ms
	STRELOAD = (STCALIB / 4) - 1;   //N=1 para 10ms
	STCURR = 0;
	ENABLE = 1;
	TICKINT = 1;
	CLKSOURCE = 1;
	return;
}
