#include "RegsLPC1769.h"
#include "RTCRegs.h"
#include "FW_GPIO.h"
#include "LCD.h"
#include "Oscilador.h"
#include "Kit.h"

/*Prototipos de funciones*/
void Inicializacion(void);
void InicSysTick(void);
void RTC_init(void);
void muestreo(void);


