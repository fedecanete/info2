#include "Aplicacion.h"

void RTC_init(void){
	PCONP |= (PCRTC<<9);
	RTCCCR |= RTC_ENABLE;
/**
 * Configuracion del RTC por default
 * Luego se lo debe configurar al tiempo requerido
 */
	RTCSEC = 0;
	RTCMIN = 30;
	RTCHOUR = 15;
	RTCDOM = 13;
	RTCDOW = 1;
	RTCDOY  = 1;
	RTCMONTH = 11;
	RTCYEAR = 2017;

/**
 * Registro de Calibracion para ajustar cada 36.4 horas --> #define VALOR_CALIB 0x20000
 *	Actualmente està deshabilitado por ser CAVAL = 0 ---> VALOR_CALIB = 0
 */
	RTCCALIBRATION &= ~(0xFFFF);
	RTCCALIBRATION |= (VALOR_CALIB);
	RTCCALIBRATION |= ~(HACIA_ADELANTE << 17);

	RTCCCR &= ~(1<<4); //Calibracion deshabilitada en el registro de control
/**
 * Interrupcion cada 1 segundo -->RTCCIIR
 */
	RTCCIIR |= (IMSEC_INTERRUPT);
	ISER0  |= (1<<RTC_bit);
}

void RTC_IRQHandler(){
	if (RTCILR &= RTCCIF){
/**
 * Interrumpiò por incremento de un contador--> en nuestro caso el de segundos
 */
		RTCILR |= RTCCIF;
		muestreo();
	}
}
