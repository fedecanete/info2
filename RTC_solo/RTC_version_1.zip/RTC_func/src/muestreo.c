#include "Aplicacion.h"

extern volatile uint8_t entero_ascii[3];

void muestreo(){
/**
 * Hora, primer renglon
 */
		Conversor(RTCHOUR);
		DisplayLCD(entero_ascii,0,6);
		DisplayLCD(":",0,7);

		Conversor(RTCMIN);
		DisplayLCD(entero_ascii,0,8);
		DisplayLCD(":",0,9);

		Conversor(RTCSEC);
		DisplayLCD(entero_ascii,0,10);
/**
 * Fecha, segundo renglon
 */
		Conversor(RTCDOM);
		DisplayLCD(entero_ascii,1,6);
		DisplayLCD("/",1,8);

		Conversor(RTCMONTH);
		DisplayLCD(entero_ascii,1,9);
		DisplayLCD("/",1,11);

		Conversor(RTCYEAR);
		DisplayLCD(entero_ascii,1,12);
}
