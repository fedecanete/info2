#include "Aplicacion.h"

extern volatile int DemoraLCD;
extern volatile uint16_t contador;

void SysTick_Handler(void) {

	Dato_LCD();
	if ( Demora_LCD )
		Demora_LCD--;

	contador++;
/**
 * Rutina para que titile el cursor
 */
	if ((contador == 300)){
	    DisplayLCD(":",0,4);		// mensaje,renglon,offset
	    DisplayLCD(":",1,3);		// mensaje,renglon,offset
	}else if(contador == 700){
		DisplayLCD(" ",0,4);		// mensaje,renglon,offset
		DisplayLCD(" ",1,3);		// mensaje,renglon,offset
		contador = 0;
	}

}
