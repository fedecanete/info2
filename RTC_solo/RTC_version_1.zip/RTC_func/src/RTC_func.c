/*
===============================================================================
 Name        : RTC_func.c
 Author      : $(author)
 Version     :
 Copyright   : $(copyright)
 Description : main definition
===============================================================================
*/

#ifdef __USE_CMSIS
#include "LPC17xx.h"
#endif
#include "Aplicacion.h"
#include <cr_section_macros.h>

/**********Variables LCD***********/
volatile int DemoraLCD;
uint8_t bufferLCD[TOPE_BUFFER_LCD];
uint8_t msg[20];
uint8_t ptrLecturaLCD = 0;
uint8_t ptrEscrituraLCD = 0;
volatile uint8_t Eventos;
volatile uint8_t entero_ascii[3];

volatile uint16_t contador = 0;

int main(void) {
	Inicializacion();
	DisplayLCD("Hora:", 0, 0);
	DisplayLCD("Fecha:", 1, 0);
    while(1) {

    }
    return 0 ;
}
