var indexSectionsWithContent =
{
  0: "abdflmpst",
  1: "s",
  2: "fp",
  3: "ablmt",
  4: "abdmt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables"
};

