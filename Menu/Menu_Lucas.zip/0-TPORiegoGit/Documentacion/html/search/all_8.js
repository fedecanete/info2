var searchData=
[
  ['tabla_5fdigitos_5fbcd_5f7seg',['Tabla_Digitos_BCD_7seg',['../_p_r__7_seg_8c.html#a1a0e5c2a77d40832bab20cb84f3594e4',1,'PR_7Seg.c']]],
  ['tecladohw',['TecladoHW',['../_f_w___teclado5x1_8c.html#a7740bbd2af933746470b9b644749392d',1,'FW_Teclado5x1.c']]]
];
