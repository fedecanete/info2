var searchData=
[
  ['tabla_5fdigitos_5fbcd_5f7seg',['Tabla_Digitos_BCD_7seg',['../_p_r__7_seg_8c.html#a1a0e5c2a77d40832bab20cb84f3594e4',1,'PR_7Seg.c']]]
];
