var searchData=
[
  ['buffkey',['buffKey',['../_f_w___teclado5x1_8c.html#a8134f4ce7e81f0c62796fcd276ddb7dc',1,'buffKey():&#160;main.c'],['../_p_r___teclado5x1_8c.html#a2795cc1b8761a4edfdececb2f2ad8842',1,'buffKey():&#160;main.c']]]
];
