#ifndef FW_GPIO_H_
#define FW_GPIO_H_

#include "RegsLPC1769.h"


//!< ----------- Estados de PINSEL:
#define		PINSEL_GPIO			0
#define		PINSEL_FUNC1		1
#define		PINSEL_FUNC2		2
#define		PINSEL_FUNC3		3

#define		ACTIVO_BAJO		0
#define		ACTIVO_ALTO		1

//!< Dirección en FIODIR
#define 	ENTRADA			0
#define 	SALIDA			1

//!< Identificadores de los puertos
#define 	PORT0			0
#define 	PORT1			1
#define 	PORT2			2
#define 	PORT3			3
#define 	PORT4			4

/*Configuracion de pines del LCD*/

#define	P05_PINSEL 	SetPINSEL(0,5,GPIO)		// d4
#define	P010_PINSEL	SetPINSEL(0,10,GPIO) 	// d5
#define	P24_PINSEL	SetPINSEL(2,4,GPIO) 	// d6
#define	P25_PINSEL	SetPINSEL(2,5,GPIO) 	// d7
#define P26_PINSEL	SetPINSEL(2,6,GPIO)		// RS
#define	P128_PINSEL	SetPINSEL(1,28,GPIO)	// BF
#define	P04_PINSEL	SetPINSEL(0,4,GPIO)		// E

//salidas o oentradas
#define FIO0DIR5	SetDIR(0,5, SALIDA)
#define FIO0DIR10	SetDIR(0,10, SALIDA)
#define FIO2DIR4	SetDIR(2,4, SALIDA)
#define FIO2DIR5	SetDIR(2,5, SALIDA)
#define FIO2DIR6	SetDIR(2,6, SALIDA)
#define FIO1DIR28	SetDIR(1,28, ENTRADA)
#define FIO0DIR4	SetDIR(0,4, SALIDA)


/*------------- General Purpose Input/Output (GPIO) --------------------------*/
typedef struct
{
	__RW register_t		FIODIR;
		 uint32_t 		RESERVED[3];
	__RW register_t 	FIOMASK;
	__RW register_t 	FIOPIN;
	__RW register_t 	FIOSET;
	__RW register_t 	FIOCLR;

} gpio_t;

#define		gpio0		( ( gpio_t  * ) 0x2009C000UL )
#define		gpio1		( ( gpio_t  * ) 0x2009C020UL )
#define		gpio2		( ( gpio_t  * ) 0x2009C040UL )

#define		FIO2PIN4		gpio2->FIOPIN.bit04
#define		FIO2PIN5		gpio2->FIOPIN.bit05
#define		FIO2PIN6		gpio2->FIOPIN.bit06

#define		FIO1PIN28		gpio1->FIOPIN.bit28

#define		FIO0PIN4		gpio0->FIOPIN.bit04
#define		FIO0PIN5		gpio0->FIOPIN.bit05
#define		FIO0PIN10		gpio0->FIOPIN.bit10





#endif /* FW_GPIO_H_ */
