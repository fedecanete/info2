
#ifndef APLICACION_H_
#define APLICACION_H_

void Inicializacion(void);					//!< Inicializacion


#endif /* APLICACION_H_ */
