/**
 	\file KitInfo2.h
 	\brief Configuracion de Infotronic
 	\author Ing. Marcelo Trujillo
 	\date 2012.04.25
*/

#include "RegsLPC1769.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>


// Varios ---------------------------------------------------------------------------------------------------
#define	ON		1
#define	OFF		0
#define	SALIDA	1
#define	ENTRADA	0

#define LED_TOGGLE_DELAY	100


// Salidas --------------------------------------------------------------------------------------------------
#define		BEEPER		FIO0PIN28		//!< Beeper

#define		relay0		FIO0PIN23		//!< Relays
#define		relay1		FIO0PIN21
#define		relay2		FIO2PIN0
#define		relay3		FIO0PIN27
#define		led0		FIO2PIN1		//!< led
#define		led1		FIO2PIN2
#define		led2		FIO2PIN3


/** -------------------------------------------------------------------------------------
 *Entradas
 */
#define		in0				FIO1PIN26
#define		in1				FIO4PIN29
#define		in2				FIO2PIN11

#define		Entrada0		(   BufferEntradas        & 0x01 )
#define		Entrada1		( ( BufferEntradas >> 1 ) & 0x01 )
#define		Entrada2		( ( BufferEntradas >> 2 ) & 0x01 )

#define		ACEPTAReSTADO	4
#define		ENTRADAS		3

#define		NO_KEY		0xff

#define ESTADOcERRADO	0
#define ESTADOaBRIENDO	1
#define ESTADOaBIERTO	2
#define ESTADOcERRANDO	3
#define ESTADOmAXIMO	4

#define	IDLE				0
#define	RELESeNTRADASaDC	1
#define UART0y1				2
#define PWM 				3
#define DAC					4


#define SENSOR1oFFsENSOR2oFF	0x00
#define SENSOR1oNsENSOR2oFF 	0x01
#define SENSOR1oFFsENSOR2oN		0x02
#define SENSOR1oNsENSOR2oN		0x03
#define SENSOR3oN				0x04

#define RELAY0	0
#define RELAY1	1
#define RELAY2	2
#define RELAY3	3

#define AZUL	0
#define ROJO	1
#define VERDE	2

#define 	MINpWM	0
#define		FULLpWM	100000
#define		DELTApWMmIN 0//20
#define		DELTApWMmAX 0//27
#define 	PASOSrEPETICION	10000

// LCD ------------------------------------------------------------------------------------------------------
void Dato_LCD ( void );
void Display_lcd ( char * , char  , char  );
void Inic_LCD ( void );
unsigned char PushLCD ( unsigned char , unsigned char );
int PopLCD ( void );
void Config_LCD( void );


//!< KitInfo2PR_gpio.c
void Led (char , char );
void Relays (char , char );

//!< KitInfo2FW_Teclado.c
void DriverTeclado( void );
void DriverTecladoSW ( unsigned char );
unsigned char DriverTecladoHW( void );
unsigned char DriverTecladoFijoHW( void );
void DriverTecladoFijo(void);
void DriverTecladoSWfijo ( unsigned char );
unsigned char TecladoFijo( void );

//!< KitInfo2PR_Teclado.c
unsigned char Teclado( void );

//!< KitInfo2FW_Entradas.c
void Debounce(void);

//!< KitInfo2FW_Inicializacion.c
void Inic_Teclado_BB( void );
void Inic_Relays( void );
void Inic_Entradas( void );
void Inic_Leds ( void );
void Inic_Expansion2( void );
void Inicializar( void );
void SysTickInic( void );
void InitDAC( void );
void InitADC( void );
int LeeADC( void );
int ConvertirMiliVolts( int );
void InitUART1( void );
void InitUART0( void );
void Inicializar_Timers(void);
void InitPLL ( void );


//ADC
void conversor ( void );

//#define	_winstar1602a
#define _winstar1602b
#define 	RENGLON_1		0
#define 	RENGLON_2		1
#define 	TOPE_BUFFER_LCD		160


#define		LCD_CONTROL		1
#define		LCD_DATA		0

