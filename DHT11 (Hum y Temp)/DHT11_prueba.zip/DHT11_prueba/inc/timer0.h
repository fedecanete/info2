/*
 * timer0.h
 *
 *  Created on: 7 de jun. de 2016
 *      Author: Gabriel
 */

#ifndef TIMER0_H_
#define TIMER0_H_

void InitTimer1(void);
void InitTimer0(void);

#endif /* TIMER0_H_ */
