/**
 \file 		RegsLPC1769.h
 \brief 	Header del MCU
 \details
 \author 	GOS
 \date 		2013.06.25
 */

#ifndef REGSLPC1769_H_
#define REGSLPC1769_H_

#include "FW_Display_Exp3.h"
#include "FW_GPIO.h"
#include "KitInfo2_BaseBoard.h"
#include "Oscilador.h"
#include "timer0.h"
#include "systick.h"
#include "Aplicacion.h"
#include "Start.h"
#include "KitInfo2.h"
#include "registros.h"

#define		__R		volatile const
#define		__W		volatile
#define		__RW	volatile

typedef unsigned int uint32_t;
typedef unsigned short uint16_t;
typedef unsigned char uint8_t;

/*Funciones GPIO*/
void SetPINSEL(uint8_t, uint8_t, uint8_t);
void SetPINMODE(uint8_t, uint8_t, uint8_t);
void SetDIR(uint8_t, uint8_t, uint8_t);
void SetPIN(uint8_t, uint8_t, uint8_t);
uint8_t GetPIN(uint8_t, uint8_t, uint8_t);


/* Tamaño del buffer debido a los 40 bits que se van a recibir del DHT11 */
#define MAX_BUFFER	5
#define	PREPARACION_DHT11	2

#define		GPIO	0
/*DEFINES UTILIZADOS EN LA FUNCION START*/
#define	PULSO	1
#define PULSO_DOWN 	0
#define PULSO_START	SetPIN(EXPANSION15,PULSO)
#define PULSO_START_DOWN	SetPIN(EXPANSION15,PULSO_DOWN)

/* Tiempos de trabajo */
#define trasmision_TIME		0x000009C4 //!< 50us
#define	one_TIME			0x00000DAC //!< 70us
#define cero_TIME			0x00000578 //!< 28us
#define	TIEMPO_START		0x000DBBA0 //!< 18ms
#define	TIEMPO_UN_PULSO		0x00000001 //!< 20ns

//!< ////////////////Registros PINSEL//////////////////////////////
//!< 0x4002C000UL : Direccion de inicio de los registros PINSEL
#define		PINSEL		( ( __RW uint32_t  * ) 0x4002C000UL )

#define		PINSEL0		PINSEL[0]	//!< PINSEL0--->P0[15:0] (0x4002C000)
#define		PINSEL1		PINSEL[1]	//!< PINSEL1--->P0[31:16](0x4002C004)
#define		PINSEL2		PINSEL[2]	//!< PINSEL2--->P1[15:0] (0x4002C008)
#define		PINSEL3		PINSEL[3]	//!< PINSEL3--->P1[31:16](0x4002C00C)
#define		PINSEL4		PINSEL[4]	//!< PINSEL4--->P2[15:0] (0x4002C010)
#define		PINSEL5		PINSEL[5]	//!< PINSEL5--->P2[31:16] NOT USED
#define		PINSEL6		PINSEL[6]	//!< PINSEL6--->P3[15:0] NOT USED
#define		PINSEL7		PINSEL[7]	//!< PINSEL7--->P3[31:16] 0x4002C01C)
#define		PINSEL8		PINSEL[8]	//!< PINSEL8--->P4[15:0]  NOT USED
#define		PINSEL9		PINSEL[9]	//!< PINSEL9--->P4[31:16](0x4002C024)
//!< ----------- Estados de PINSEL:
#define		PINSEL_GPIO			0
#define		PINSEL_FUNC1		1
#define		PINSEL_FUNC2		2
#define		PINSEL_FUNC3		3

//!< //////////////////Registros PINMODE ///////////////////////////
//!< 0x4002C040UL : Direccion de inicio de los registros de modo de los pines del GPIO
#define	PINMODE		( ( __RW uint32_t  * ) 0x4002C040UL )

#define		PINMODE0	PINMODE[0]		//!< 0x4002C040
#define		PINMODE1	PINMODE[1]		//!< 0x4002C044
#define		PINMODE2	PINMODE[2]		//!< 0x4002C048
#define		PINMODE3	PINMODE[3]		//!< 0x4002C04C
#define		PINMODE4	PINMODE[4]		//!< 0x4002C050
#define		PINMODE5	PINMODE[5]		//!< 0x4002C054
#define		PINMODE6	PINMODE[6]		//!< 0x4002C058
#define		PINMODE7	PINMODE[7]		//!< 0x4002C05C
#define		PINMODE9	PINMODE[9]		//!< 0x4002C064
//!< ----------- Estados de PINMODE
//!< 00	Pull Up resistor enable (reset value)		01	repeated mode enable
//!< 11	Pull Down resistor enable					10	ni Pull Up ni Pull DOwn
#define		PINMODE_PULLUP 		0
#define		PINMODE_REPEAT 		1
#define		PINMODE_NONE 		2
#define		PINMODE_PULLDOWN 	3

//!< ///////////////// REGISTROS PINMODE_OD ///////////////////////////
//!< 0x4002C068UL : Direccion de inicio de los registros de control del modo OPEN DRAIN
#define		PINMODE_OD		( ( __RW uint32_t  * ) 0x4002C068UL )

#define		PINMODE_OD0		PINMODE_OD[0]
#define		PINMODE_OD1		PINMODE_OD[1]
#define		PINMODE_OD2		PINMODE_OD[2]
#define		PINMODE_OD3		PINMODE_OD[3]
#define		PINMODE_OD4		PINMODE_OD[4]

//!< ////////////////// REGISTROS GPIOs //////////////////////////////
//!< 0x2009C000UL : Direccion de inicio de los registros de GPIOs
#define	GPIOs		( ( __RW uint32_t  * ) 0x2009C000UL )

/*	*						*
 *************************
 *		FIODIR			*	0x2009C000
 *************************
 *		RESERVED		*	0x2009C004
 *************************
 *		RESERVED		*	0x2009C008
 *************************
 *		RESERVED		*	0x2009C00C
 *************************
 *		FIOMASK			*	0x2009C010
 *************************
 *		FIOPIN			*	0x2009C014
 *************************
 *		FIOSET			*	0x2009C018
 *************************
 *		FIOCLR			*	0x2009C01C
 *************************
 *						*
 *						*
 */
#define		FIO0DIR		GPIOs[0]	//!< 0x2009C000
#define		FIO1DIR		GPIOs[8]	//!< 0x2009C020
#define		FIO2DIR		GPIOs[16]	//!< 0x2009C040
#define		FIO3DIR		GPIOs[24]	//!< 0x2009C060
#define		FIO4DIR		GPIOs[32]	//!< 0x2009C080
#define		FIO0MASK	GPIOs[4]	//!< 0x2009C010
#define		FIO1MASK	GPIOs[12]	//!< 0x2009C030
#define		FIO2MASK	GPIOs[20]	//!< 0x2009C050
#define		FIO3MASK	GPIOs[28]	//!< 0x2009C070
#define		FIO4MASK	GPIOs[36]	//!< 0x2009C090
#define		FIO0PIN		GPIOs[5]	//!< 0x2009C014
#define		FIO1PIN		GPIOs[13]	//!< 0x2009C034
#define		FIO2PIN		GPIOs[21]	//!< 0x2009C054
#define		FIO3PIN		GPIOs[29]	//!< 0x2009C074
#define		FIO4PIN		GPIOs[37]	//!< 0x2009C094
#define		FIO0SET		GPIOs[6]	//!< 0x2009C018
#define		FIO1SET		GPIOs[14]	//!< 0x2009C038
#define		FIO2SET		GPIOs[22]	//!< 0x2009C058
#define		FIO3SET		GPIOs[30]	//!< 0x2009C078
#define		FIO4SET		GPIOs[38]	//!< 0x2009C098
#define		FIO0CLR		GPIOs[7]	//!< 0x2009C01C
#define		FIO1CLR		GPIOs[15]	//!< 0x2009C03C
#define		FIO2CLR		GPIOs[23]	//!< 0x2009C05C
#define		FIO3CLR		GPIOs[31]	//!< 0x2009C07C
#define		FIO4CLR		GPIOs[39]	//!< 0x2009C09C
//!< Dirección en FIODIR
#define 	ENTRADA			0
#define 	SALIDA			1

//!< NVIC
#define		ISER 		( ( __RW uint32_t  * ) 0xE000E100UL )
#define 	ISER0		ISER[0]
#define 	ISER1		ISER[1]

#define		ICER 		( ( __RW uint32_t  * ) 0xE000E180UL )
#define		ICER0		ICER[0]
#define		ICER1		ICER[1]

#define		ISPR 		( ( __RW uint32_t  * ) 0xE000E200UL )
#define		ISPR0		ISPR[0]
#define		ISPR1		ISPR[1]

#define		ICPR 		( ( __RW uint32_t  * ) 0xE000E280UL )
#define		ICPR0		ICPR[0]
#define		ICPR1		ICPR[1]

#define		IABR 		( ( __RW uint32_t  * ) 0xE000E300UL )
#define		IABR0		IABR[0]
#define		IABR1		IABR[1]

#define		IPR 		( ( __RW uint32_t  * ) 0xE000E400UL )
#define		IPR0		IPR[0]
#define		IPR1		IPR[1]
#define		IPR2		IPR[2]
#define		IPR3		IPR[3]
#define		IPR4		IPR[4]
#define		IPR5		IPR[5]
#define		IPR6		IPR[6]
#define		IPR7		IPR[7]
#define		IPR8		IPR[8]

#define		STIR_ 		( ( __RW uint32_t  * ) 0xE000EF00UL )
#define		STIR 		STIR_[0]

//!< Interrupciones Externas
#define		EXTINT_ 	( ( __RW uint32_t  * ) 0x400FC140UL )
#define		EXTINT		EXTINT_[0]

#define		EXTMODE_ 	( ( __RW uint32_t  * ) 0x400FC148UL )
#define		EXTMODE		EXTMODE_[0]

#define		EXTPOLAR_ 	( ( __RW uint32_t  * ) 0x400FC14CUL )
#define 	EXTPOLAR	EXTPOLAR_[0]

#define 	EINT0  	0
#define 	EINT1  	1
#define 	EINT2  	2
#define 	EINT3  	3

//!< Interrupciones GPIO
#define		IOIntStatus_ 		( ( __RW uint32_t  * ) 0x40028080UL )
#define		IOIntStatus		IOIntStatus_[0]

//!< P0
#define		IO0IntStatR_ 		( ( __RW uint32_t  * ) 0x40028084UL )
#define		IO0IntStatR		IO0IntStatR_[0]

#define		IO0IntStatF_ 		( ( __RW uint32_t  * ) 0x40028088UL )
#define		IO0IntStatF		IO0IntStatF_[0]

#define		IO0IntClr_ 		( ( __RW uint32_t  * ) 0x4002808CUL )
#define		IO0IntClr		IO0IntClr_[0]

#define		IO0IntEnR_ 		( ( __RW uint32_t  * ) 0x40028090UL )
#define		IO0IntEnR		IO0IntEnR_[0]

#define		IO0IntEnF_ 		( ( __RW uint32_t  * ) 0x40028094UL )
#define		IO0IntEnF		IO0IntEnF_[0]

//!< P2
#define		IO2IntStatR_ 		( ( __RW uint32_t  * ) 0x400280A4UL )
#define		IO2IntStatR			IO2IntStatR_[0]

#define		IO2IntStatF_ 		( ( __RW uint32_t  * ) 0x400280A8UL )
#define		IO2IntStatF			IO2IntStatF_[0]

#define		IO2IntClr_ 		( ( __RW uint32_t  * ) 0x400280ACUL )
#define		IO2IntClr		IO2IntClr_[0]

#define		IO2IntEnR_ 		( ( __RW uint32_t  * ) 0x400280B0UL )
#define		IO2IntEnR		IO2IntEnR_[0]

#define		IO2IntEnF_ 		( ( __RW uint32_t  * ) 0x400280B4UL )
#define		IO2IntEnF		IO2IntEnF_[0]

//!< ///////////////////   PCONP   //////////////////////////
//!<  Power Control for Peripherals register (PCONP - 0x400F C0C4) [pag. 62 user manual LPC1769]
//!< 0x400FC0C4UL : Direccion de inicio del registro de habilitación de dispositivos:
#define 	PCONP	(* ( ( __RW uint32_t  * ) 0x400FC0C4UL ))

//!< ///////////////////   PCLKSEL   //////////////////////////
//!< Peripheral Clock Selection registers 0 and 1 (PCLKSEL0 -0x400F C1A8 and PCLKSEL1 - 0x400F C1AC) [pag. 56 user manual]
//!< 0x400FC1A8UL : Direccion de inicio de los registros de seleccion de los CLKs de los dispositivos:
#define		PCLKSEL		( ( __RW uint32_t  * ) 0x400FC1A8UL )
//!< Registros PCLKSEL
#define		PCLKSEL0	PCLKSEL[0]
#define		PCLKSEL1	PCLKSEL[1]

//!< /////////////		SYSTICK		///////////////////////////
//!< Tipo de dato específico para manejar el SYSTICK
typedef struct {
	union {
		__RW uint32_t _STCTRL;
		struct {
			__RW uint32_t _ENABLE :1;
			__RW uint32_t _TICKINT :1;
			__RW uint32_t _CLKSOURCE :1;
			__RW uint32_t _RESERVED0 :12;
			__RW uint32_t _COUNTFLAG :1;
			__RW uint32_t _RESERVED1 :16;
		} bits;
	};
	__RW uint32_t _STRELOAD;
	__RW uint32_t _STCURR;
	__R uint32_t _STCALIB;
} systick_t;

//!< 0xE000E010UL: Registro de control del SysTick:
#define 	DIR_SYSTICK		( (systick_t *) 0xE000E010UL )

#define		STCTRL		DIR_SYSTICK->_STCTRL
#define	ENABLE			DIR_SYSTICK->bits._ENABLE
#define	TICKINT			DIR_SYSTICK->bits._TICKINT
#define	CLKSOURCE		DIR_SYSTICK->bits._CLKSOURCE
#define	COUNTFLAG		DIR_SYSTICK->bits._COUNTFLAG
#define		STRELOAD	DIR_SYSTICK->_STRELOAD
#define		STCURR		DIR_SYSTICK->_STCURR
#define		STCALIB		DIR_SYSTICK->_STCALIB

#define 	N 		1	//Si N=1, Systick interrumpe cada 10ms.


//!< Timers
//!< Timer 0
	#define		TIMER0 		( ( __RW uint32_t  * ) 0x40004000UL )
	#define		T0IR		TIMER0[0]
	#define		T0TCR		TIMER0[1]
	#define		T0TC		TIMER0[2]
	#define		T0PR		TIMER0[3]
	#define		T0PC		TIMER0[4]
	#define		T0MCR		TIMER0[5]
	#define		T0MR0		TIMER0[6]
	#define		T0MR1		TIMER0[7]
	#define		T0MR2		TIMER0[8]
	#define		T0MR3		TIMER0[9]
	#define		T0CCR		TIMER0[10]
	#define		T0CR0		TIMER0[11]
	#define		T0CR1		TIMER0[12]

	#define		_T0EMR	( ( __RW uint32_t  * ) 0x4000403CUL )
	#define		T0EMR	_T0EMR[0]

	#define		_T0CTCR	( ( __RW uint32_t  * ) 0x40004070UL )
	#define		T0CTCR	_T0CTCR[0]

	//!< Timer 1
	#define		TIMER1 		( ( __RW uint32_t  * ) 0x40008000UL )
	#define		T1IR		TIMER1[0]
	#define		T1TCR		TIMER1[1]
	#define		T1TC		TIMER1[2]
	#define		T1PR		TIMER1[3]
	#define		T1PC		TIMER1[4]
	#define		T1MCR		TIMER1[5]
	#define		T1MR0		TIMER1[6]
	#define		T1MR1		TIMER1[7]
	#define		T1MR2		TIMER1[8]
	#define		T1MR3		TIMER1[9]
	#define		T1CCR		TIMER1[10]
	#define		T1CR0		TIMER1[11]
	#define		T1CR1		TIMER1[12]

	#define		_T1EMR	( ( __RW uint32_t  * ) 0x4000803CUL )
	#define		T1EMR	_T1EMR[0]

	#define		_T1CTCR	( ( __RW uint32_t  * ) 0x40008070UL )
	#define		T1CTCR	_T1CTCR[0]

	#define 	ALIMENTA_T1			0x00000004
	#define 	PCLK_T1				0x00000020
	#define		INT_T1_EN			0x00000004
	#define 	SET_CAP1_0			SetPINSEL(EXPANSION15,PINSEL_FUNC3)
	#define 	SET_PINMODE_CAP1_0	SetPINMODE(EXPANSION15,0x00)
	#define 	SET_CAP1_0_GPIO		SetPINSEL(EXPANSION15,GPIO)
	#define		SET_DIR_CAP1_0		SetDIR(EXPANSION15,SALIDA)
	#define 	CLR_T1IR			0x20

	//!< Timer 2
	#define		TIMER2 		( ( __RW uint32_t  * ) 0x40090000UL )
	#define		T2IR		TIMER2[0]
	#define		T2TCR		TIMER2[1]
	#define		T2TC		TIMER2[2]
	#define		T2PR		TIMER2[3]
	#define		T2PC		TIMER2[4]
	#define		T2MCR		TIMER2[5]
	#define		T2MR0		TIMER2[6]
	#define		T2MR1		TIMER2[7]
	#define		T2MR2		TIMER2[8]
	#define		T2MR3		TIMER2[9]
	#define		T2CCR		TIMER2[10]
	#define		T2CR0		TIMER2[11]
	#define		T2CR1		TIMER2[12]

	#define		_T2EMR	( ( __RW uint32_t  * ) 0x4009003CUL )
	#define		T2EMR	_T2EMR[0]

	#define		_T2CTCR	( ( __RW uint32_t  * ) 0x40090070UL )
	#define		T2CTCR	_T2CTCR[0]

	//!< Timer 3
	#define		TIMER3 		( ( __RW uint32_t  * ) 0x40094000UL )
	#define		T3IR		TIMER3[0]
	#define		T3TCR		TIMER3[1]
	#define		T3TC		TIMER3[2]
	#define		T3PR		TIMER3[3]
	#define		T3PC		TIMER3[4]
	#define		T3MCR		TIMER3[5]
	#define		T3MR0		TIMER3[6]
	#define		T3MR1		TIMER3[7]
	#define		T3MR2		TIMER3[8]
	#define		T3MR3		TIMER3[9]
	#define		T3CCR		TIMER3[10]
	#define		T3CR0		TIMER3[11]
	#define		T3CR1		TIMER3[12]

	#define		_T3EMR	( ( __RW uint32_t  * ) 0x4009403CUL )
	#define		T3EMR	_T3EMR[0]

	#define		_T3CTCR	( ( __RW uint32_t  * ) 0x40094070UL )
	#define		T3CTCR	_T3CTCR[0]

	#define ALIMENTA_T0			0x00000002
	#define PCLK_T0				0x00000004
	#define PREESCALER			0x00
	#define CLR_T0IR			0xFFFFFFFE
	#define TIMER_CAPT0			0xFFFFFFF0
	#define	TIMER_MODE			0xFFFFFFFE
	#define RESET_CAPT0			0xFFFFFFF8
	#define CAPT0_INT_FE		0x00000006
	#define INT_TO_EN			0x00000002
	#define CLEAR_RST_EN		0xFFFFFFFC
	#define TIMER_OFFyRST		0x00000002
	#define TIMER_RST_OFF		0xFFFFFFFD
	#define TIMER_ON			0x00000001
	#define TIMER_OFF			0xFFFFFFFC
	#define MATCH00				3
	#define MATCH01				6
	#define TIMER				0xFFFFFFFC
	#define TIMER_COUNTER_CLR	0xFFFFFFF0
	#define COUNTER_BOTH_EDGES	0x00000003
	#define CLEAR_MCR0		 	0xFFFFFFF8
	#define	MR0I_ENABLE			0x00000001
	#define	MR0I_DISABLE		0xFFFFFFFE
	#define MR1I_ENABLE			0x00000008
	#define	MR1I_DISABLE		0xFFFFFFF7
	#define	MR0_STOP			0x00000004
	#define	MR1_STOP			0x00000020
	#define MR1_RESET			0x00000010
	#define MR0_RESET			0x00000002

	#define CLR_MTCH_CONFIG		0xFFFFF000
	#define MATCH0_INT			0x00000001
	#define MATCH0_RST			0x00000002
	#define MATCH0_STP			0x00000004

	#define MATCH0_INT			0x00000001
	#define MATCH1_INT_RST		0x00000018

	#define MR0					0x01
	#define MR1					0x02

/*LCD pines de puerto*/
#define		LCD_d4			FIO0PIN5
#define		LCD_d5			FIO0PIN10
#define		LCD_d6			FIO2PIN4
#define		LCD_d7			FIO2PIN5
#define		LCD_RS			FIO2PIN6
#define		LCD_BF			FIO1PIN28
#define		LCD_E			FIO0PIN4

#endif /* REGS_H_ */
