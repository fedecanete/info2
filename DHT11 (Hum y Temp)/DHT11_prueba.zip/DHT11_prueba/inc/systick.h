/*
 * systick.h
 *
 *  Created on: 7 de jun. de 2016
 *      Author: Gabriel
 */

#ifndef SYSTICK_H_
#define SYSTICK_H_

void InicSysTick(void);				//!< Inicialización de SysTick

#endif /* SYSTICK_H_ */
