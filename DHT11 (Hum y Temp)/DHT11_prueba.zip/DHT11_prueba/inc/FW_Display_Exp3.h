/**
 \file 		FW_Display_Exp3.h
 \brief 	Header de Exp3
 \details
 \author 	Ing. Marcelo Trujillo
 \date 		2013.09.07
 */


#ifndef FW_DISPLAY_EXP3_H_
#define FW_DISPLAY_EXP3_H_

	#include "RegsLPC1769.h"



	/** -------------------------------------------------------------------------------------
	 *PLACA EXPANSION 3
	 */
	//!< Display
	#define		BCD_A			EXPANSION0
	#define		BCD_B			EXPANSION1
	#define		BCD_C			EXPANSION2
	#define		BCD_D			EXPANSION3
	#define		EXP3_dp			EXPANSION4


	#define		BCD_RST			EXPANSION6
	#define		BCD_CLOCK		EXPANSION5


	#define		DIGITOS			6

	#define		DSP0			0			//!< Display rojo
	#define		DSP1			1

	//!< Teclado
	#define		FILA0			EXPANSION7
	#define		FILA1			EXPANSION8
	#define		FILA2			EXPANSION9
	#define		FILA3			EXPANSION10
	#define		COL0			EXPANSION11
	#define		COL1			EXPANSION12

	#define		SW1			1
	#define		SW2			2
	#define		SW3			3
	#define		SW4			4
	#define		SW5			5
	#define		SW6			6
	#define		SW7			7
	#define		SW8			8


#endif /* FW_DISPLAY_EXP3_H_ */
