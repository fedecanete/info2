/**
 	\file KitInfo2PR_LCD.c
 	\brief Primitiva del LCD
 	\details Validas para LCD de 2 lineas
 	\author Ing. Marcelo Trujillo
 	\date 2012.04.25
*/
#include "RegsLPC1769.h"

extern uint8_t entero_ascii[];

/**
 * void Conversor(uint16_t valor_int)
 * Convierte un entero sin signo en ascii
 *
 * */
void Conversor(uint16_t valor_int){
	entero_ascii[4] = valor_int % 10 +48;
	valor_int /= 10;

	entero_ascii[3] = valor_int % 10 +48;
	valor_int /= 10;

	entero_ascii[2] = valor_int % 10 +48;
	valor_int /= 10;

	entero_ascii[1] = valor_int % 10 +48;
	entero_ascii[0] = valor_int /10 +48;

}

void Display_lcd( char * msg, char r , char p )
{
	unsigned char i ;

	switch ( r )
	{
		case RENGLON_1:
			PushLCD( p + 0x80 , LCD_CONTROL );
			break;
		case RENGLON_2:
			PushLCD( p + 0xc0 , LCD_CONTROL );
			break;
	}
	for( i = 0 ; msg[ i ] != '\0' ; i++ )
		PushLCD( msg [ i ] , LCD_DATA );
}
