/**
 \file:		Aplicacion.c
 \brief: 	Aplicacion
 \details: 	Programa de control de la maquina
 \author: 	GOS
 \date:		2013.09.07
 */


#include "RegsLPC1769.h"


extern volatile uint8_t buffer_entrada[];
extern volatile uint8_t trasmision_FLAG;
extern volatile uint8_t START_FLAG;
extern volatile uint8_t Buffer_lleno;
extern uint8_t entero_ascii[];
/**
 * Aplicacion: Se encarga de procesar la informacion enviada por el DHT11
 */
void Aplicacion(void) {
	int i = 0;
	if(trasmision_FLAG == 0){
		START_FLAG = 1;
		Start();		//!< condicion de START para el DHT11
	}

	if(Buffer_lleno){
		for(i=0; i<MAX_BUFFER;i++){
			entero_ascii[i] = buffer_entrada[i];
		}
		Display_lcd("Humedad: ", 0, 0);
		Display_lcd(entero_ascii[0], 0, 10);
		Display_lcd("Temp: ", 1, 0);
		Display_lcd(entero_ascii[2], 1, 7);
		Buffer_lleno = 0; //!< Limpio el flag del buffer
	}
	//!< Se deberian esperar 40 ms aprox hasta que el DHT11 envie la señal preparatoria
}
