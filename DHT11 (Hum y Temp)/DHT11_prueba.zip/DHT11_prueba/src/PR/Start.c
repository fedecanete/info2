/**
 \file:		Start.c
 \brief: 	Start
 \details: 	Programa que da la señal de 18ms de inicio al modulo DHT11
 \author: 	GOS
 \date:		2017
 */

#include "RegsLPC1769.h"

extern volatile uint8_t count; //!< cuenta los pulsos cada 20ns
/**
 * Start: setea el pin p1.18 como salida para enviar la señal de 18ms de START al modulo DHT11
 */

void Start(void){
	SET_CAP1_0_GPIO;		//pongo al pin de captura como GPIO
	SET_DIR_CAP1_0;			//P1.18 como salida
	PULSO_START;			//!< Mando un 1 al pin de puerto
	T0TCR 	|= TIMER_ON;	//!< Enciendo timer0 para que cuente 23ms ---> genera interrupcion en el match0
}


