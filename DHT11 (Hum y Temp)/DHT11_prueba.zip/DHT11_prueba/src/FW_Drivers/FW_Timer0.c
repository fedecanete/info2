/**
 \file		: FW_Timer1.c
 \brief     : Rutinas asociadas al Timer 1
 \details   :
 \author    : GOS
 \date 	    : 2017
*/

#include "RegsLPC1769.h"

extern volatile uint8_t START_FLAG;
/**
 * InitTimer1() : inicializa timer 1 para trabajar contando pulsos de captura CAP1.0 EXP15 P1.18, leyendo informacion del DHT11
*/
void InitTimer1(void){

	SET_CAP1_0;					//!< SW13 P1.18 como CAP1.0
	SET_PINMODE_CAP1_0;			//!< Configurar pin mode como pull up para P1.0

	PCONP		|= ALIMENTA_T1;			//!< Habilitar Timer 1
	PCLKSEL0 	|= PCLK_T1;				//!< Clock for timer PCLK = CCLK/2 Selecciono clock 50MHz--->20ns

	T1CTCR 		&= TIMER_COUNTER_CLR;	//!< Cuenta pulsos de CAP1.0
	T1CTCR 		|= COUNTER_BOTH_EDGES;	//!< Contador de pulsos ambos flancos en P1.18
	T1TCR 		&= CLEAR_RST_EN;		//!< Limpio bits de control de reset y encendido del timer
	T1TCR 		|= TIMER_OFFyRST;		//!< Apago y reseteo el temporizador
	T1TCR 		&= TIMER_RST_OFF;		//!< Limpio bit de control de reset
	T1TCR 		|= TIMER_ON;			//!< Enciendo timer
	ISER0 		|= INT_T1_EN;  			//!< Habilito Interrupcion TIMER1
}

void InitTimer0(void){

	PCONP		|= ALIMENTA_T0;			//!< Habilitar Timer 0
	PCLKSEL0 	|= PCLK_T1;				//!< Clock for timer PCLK = CCLK/2 Selecciono clock 50MHz--->20ns
										//!< Uso PCLK_T1 porque contiene el divisor para tener 20ns
	T0CTCR		&= TIMER_MODE;			//!< Timer como Timer, no como contador

	T0MCR		&= CLEAR_MCR0;			//!< Pongo en "0" los bits de MR0I, MR0R y MR0S
	T0MCR		|= MR0I_ENABLE;			//!< Habilito la interrupcion del match0 timer0
	T0MCR		|= MR1I_ENABLE;			//!< Habilito la interrupcion del match1 timer0
//	T0MR0		|= MR0_STOP;			//!< Habilito que se detenga el timer cuando se alcance el match
//	T0MR1		|= MR1_STOP;			//!< Habilito que se detenga el timer cuando se alcance el match
	T0MR1		|= MR1_RESET;			//!< Que ante un match1 se resetee el contador
	T0MR0		|= MR0_RESET;			//!< Que ante un match1 se resetee el contador
	T0MCR		&= MR1I_DISABLE;		//!< Deshabilito la interrupcion del match1
	T0MR0		|=	TIEMPO_START;		//!< Configuro para un tiempo de 18ms en los cuales se enviará la señal de START al DHT11
										//!< 900000 pulsos para 18ms con un periodo de a 20ns
	T0MR1		|=	TIEMPO_UN_PULSO;	//!< Configuro al match para que salte por cada pulso de 20ns
//	T0MR2		|=
//	T0MR3		|=

	T0TCR 		&= CLEAR_RST_EN;		//!< Limpio bits de control de reset y encendido del timer
	T0TCR 		|= TIMER_OFFyRST;		//!< Apago y reseteo el temporizador
	T0TCR 		&= TIMER_RST_OFF;		//!< Limpio bit de control de reset
	//T0TCR 		|= TIMER_ON;			//!< Enciendo timer
	ISER0 		|= INT_TO_EN;  			//!< Habilito Interrupcion TIMER0
}

/**
 * \fn void TIMER1_IRQHandler (void)
 * */

extern volatile uint8_t buffer_entrada[];
extern volatile uint8_t count_respuesta;
extern volatile uint8_t count_bytes;
extern volatile uint8_t	count_bits;
extern volatile uint8_t trasmision_FLAG;
extern volatile uint32_t count;
extern volatile uint8_t START_FLAG;
extern volatile uint8_t flanco_FLAG;
extern volatile uint8_t Buffer_lleno;


void TIMER1_IRQHandler (void){
	trasmision_FLAG = 1;
	//!< Si detecta flanco ascendente de RESPUSTA se dispara y viene a la rutina
	if(count_respuesta < PREPARACION_DHT11){ 	//!< El contador va a valer 2 cuando halla detectado el flanco ascendente
												//!< y descendente de 80us de RESPUESTA del DHT11
		T1IR &= CLR_T1IR;			//!< Limpio el bit de interrupción de captura del channel 1
		count_respuesta++;
	}else{
		if(flanco_FLAG){			//!< flanco_FLAG me indica con 1 que es el flanco ascendente, con 0 es descendente
			T0MCR	|= MR1I_ENABLE;			//!< Habilito la interrupcion del match1 timer0
			T0TCR 		|= TIMER_ON;			//!< Enciendo timer0
			flanco_FLAG = 0;
		}else{
			flanco_FLAG = 1;
		}

		switch(count){
		case trasmision_TIME:
			T1IR &= CLR_T1IR;			//!< Limpio el bit de interrupción de captura del channel 1
			count = 0;
			break;
		case one_TIME:
			T1IR &= CLR_T1IR;			//!< Limpio el bit de interrupción de captura del channel 1
			buffer_entrada[count_bytes] |= 1<<count_bits;		//!< almaceno el 1 en la posicion del bit para el buffer
			count_bits++;
			count = 0;
			break;
		case cero_TIME:
			T1IR &= CLR_T1IR;			//!< Limpio el bit de interrupción de captura del channel 1
			buffer_entrada[count_bytes] &= ~(1<<count_bits); 	//!< almaceno el 0 en la posicion del bit para el buffer
			count_bits++;
			count = 0;
			break;
		default:
			count = 0;
			break;
		}
		if(count_bits == 8){
			count_bits = 0;
			count_bytes++;
		}
		if(count_bytes > MAX_BUFFER){
			count_bytes = 0;
			count_respuesta = 0;
			trasmision_FLAG = 0;
			Buffer_lleno = 1; //!< Flag que avisa que el buffer esta completo para muestrear
		}
	}
}

void TIMER0_IRQHandler (void){
	if(START_FLAG){
		//!< Si llegó hasta acá ya pasaron 18ms asique invierto la configuracion del puerto P1.18 para que lea
		PULSO_START_DOWN;		//!< Mando un 0 al pin de puerto
		SET_CAP1_0;				//!<Vuelve a ser input capture
		SET_PINMODE_CAP1_0;		//!< Configurar pin mode como pull up para P1.18
		T0IR &= CLR_T0IR;		//!< Limpio el Flag de la interrupcion del match0
		T0TCR 		&= CLEAR_RST_EN;		//!< Limpio bits de control de reset y encendido del timer
		T0TCR 		|= TIMER_OFFyRST;		//!< Apago y reseteo el temporizador
		START_FLAG = 0;
		T0MCR	&= MR0I_DISABLE;//!< Deshabilito la interrupcion del match0 timer0
	}else if(!START_FLAG){
		count++;
	}
}

