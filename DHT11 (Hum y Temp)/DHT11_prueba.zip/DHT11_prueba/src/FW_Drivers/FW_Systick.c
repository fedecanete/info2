/**
 \file FW_SysTick.c
 \brief Funciones del SysTick
 \details
 \author Ing. Marcelo Trujillo
 \date 2012.04.25
 */
#include "RegsLPC1769.h"

extern uint16_t demoraArranque;				//!< Variable de demora de arranque de la máquina

/**
 \fn 		void InicSysTick(void)
 \brief 	Inicialización de SysTick para 2,5ms de tick
 \param 	void
 \return	void
 */
void InicSysTick(void) {
	//!< si divido x 4, interrumpe cada 2,5ms
	STRELOAD = (STCALIB / 4) - 1;   //!< N=1 para 10ms
	STCURR = 0;

	ENABLE = 1;
	TICKINT = 1;
	CLKSOURCE = 1;
	return;
}


/**
 \fn void SysTick_Handler(void)
 \brief Isr del SysTick
 \param void
 \return void
 */
void SysTick_Handler(void) {

	Dato_LCD( );

	if ( Demora_LCD )
		Demora_LCD--;
}
