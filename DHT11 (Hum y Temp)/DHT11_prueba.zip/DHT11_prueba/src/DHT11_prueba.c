/*
===============================================================================
 Name        : DHT11_prueba.c
 Author      : $(author)
 Version     :
 Copyright   : $(copyright)
 Description : main definition
===============================================================================
*/

#ifdef __USE_CMSIS
#include "RegsLPC1769.h"
#endif

#include <cr_section_macros.h>

volatile uint8_t buffer_entrada[MAX_BUFFER];
volatile uint8_t count_respuesta = 0;		//!< Se va a encargar de contar los bytes que van ingresando en el buffer
volatile uint8_t count_bytes = 0;
volatile uint8_t count_bits = 0;
volatile uint8_t trasmision_FLAG = 0;
volatile uint32_t count = 0;
volatile uint8_t START_FLAG = 0;
volatile uint8_t flanco_FLAG = 1;
volatile uint8_t Buffer_lleno = 0;
uint8_t entero_ascii[MAX_BUFFER];


int main(void) {
	Inicializacion();
	Display_lcd("Prueba", 0, 0);
	while (1) {
		Aplicacion();

	}
	return 0;
}
