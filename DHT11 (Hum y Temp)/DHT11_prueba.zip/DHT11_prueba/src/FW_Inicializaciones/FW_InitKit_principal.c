/**
 \file 		KitInic.c
 \brief 	Inicializacion de kit y SysTick
 \details
 \author 	Ing. Marcelo Trujillo
 \date 		2013.07.09
 */


#include "RegsLPC1769.h"


/**
 * Inicializacion: Da las condiciones de comienzo y seteos de pines, timers, para
 * 					el funcionamiento del programa.
 * */
void Inicializacion(void) {
	InicPLL();
	//!< ESCRIBIR CODIGO DE OTRAS INICIALIZACIONES A PARTIR DE AQUI   <<<-----------------------
	InitTimer0();
	InitTimer1();
	InicSysTick();
}

