#include "Aplicacion.h"

extern volatile int DemoraLCD;
extern volatile uint16_t contador;
extern uint8_t entero_ascii[];
extern uint8_t i;
void SysTick_Handler(void) {

	Dato_LCD();
	if ( Demora_LCD )
		Demora_LCD--;

	contador++;
	if ((contador == 500)){
		Conversor(i++);
		contador = 0;
		DisplayLCD(entero_ascii,1,9);
	}
}
