#include "Aplicacion.h"


/**
 * Variables globales para Aplicacion.c
 */
extern volatile uint8_t START_FLAG;
extern volatile uint8_t ESPERA_FLAG;
extern volatile uint8_t PULSOS_FLAG;
extern volatile uint8_t PASO_ESPERA;
extern volatile uint8_t PASO_START;
/**
 * Variables globales para Proceso_lectura
 */
extern volatile uint8_t buffer_entrada[];
extern volatile uint8_t count_respuesta;
extern volatile uint8_t count_bytes;
extern volatile uint8_t	count_bits;
extern volatile uint8_t trasmision_FLAG;
extern volatile uint32_t count;
extern volatile uint8_t START_FLAG;
extern volatile uint8_t flanco_FLAG;
extern volatile uint8_t Buffer_lleno;
extern volatile uint32_t capturaT1Ch1;				//!< Variables que guarda captura

void Aplicacion(){
	if(!START_FLAG && !ESPERA_FLAG){
		START_FLAG = 1;
		/**
		 * Seteo al pin P1.18 como GPIO para mandar señal de START 18ms y ESPERA
		 */
		SetPINSEL(EXPANSION15,PINSEL_GPIO);
		SetDIR(EXPANSION15,SALIDA);
		SetMODE_OD(EXPANSION15,OPEN_DRAIN);
		PULSO_START;
		T0TCR 		&= CLEAR_RST_EN;		//!< Limpio bits de control de reset y encendido del timer
		T0TCR 		|= TIMER_OFFyRST;		//!< Apago y reseteo el temporizador
		T0TCR 		&= TIMER_RST_OFF;		//!< Limpio bit de control de reset
		T0TCR 		|= TIMER_ON;			//!< Enciendo timer1
	}
	if(START_FLAG && !ESPERA_FLAG && PASO_START){
		ESPERA_FLAG = 1;
		PULSO_ESPERA;
		T0TCR 		&= CLEAR_RST_EN;		//!< Limpio bits de control de reset y encendido del timer
		T0TCR 		|= TIMER_OFFyRST;		//!< Apago y reseteo el temporizador
		T0TCR 		&= TIMER_RST_OFF;		//!< Limpio bit de control de reset
		T0TCR 		|= TIMER_ON;			//!< Enciendo timer1
	}
	if(Buffer_lleno){
		/**
		 * Aca se muestra en el LCD los valores de temperatura y humedad
		 */
	}
}

void Proceso_lectura(){
		/**
		 * Caso para tomar la informacion como "1"
		 */
		if((capturaT1Ch1 > 30)&&(capturaT1Ch1 < 60)){
			buffer_entrada[count_bytes] |= 1<<count_bits;		//!< almaceno el 1 en la posicion del bit para el buffer
			count_bits++;
		}
		/**
		 * Caso para tomar la informacion como "0"
		 */
		if((capturaT1Ch1 > 0)&&(capturaT1Ch1 < 30)){
			buffer_entrada[count_bytes] &= ~(1<<count_bits); 	//!< almaceno el 0 en la posicion del bit para el buffer
			count_bits++;
		}

		if(count_bits == 8){
			count_bits = 0;
			count_bytes++;
		}
		if(count_bytes < MAX_BUFFER){			//!< 40 bits de datos ---> 5 bytes trasmitidos
			count_bytes = 0;
			count_respuesta = 0;
			trasmision_FLAG = 0;

			START_FLAG = 0;
			ESPERA_FLAG = 0;
			Buffer_lleno = 1; //!< Flag que avisa que el buffer esta completo para muestrear
		}
}
