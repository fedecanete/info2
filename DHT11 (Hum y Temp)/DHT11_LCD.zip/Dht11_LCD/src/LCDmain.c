/*
===============================================================================
 Name        : LCD.c
 Author      : $(author)
 Version     :
 Copyright   : $(copyright)
 Description : main definition
===============================================================================
*/

#ifdef __USE_CMSIS
#include "LPC17xx.h"
#endif

#include "Aplicacion.h"
#include <cr_section_macros.h>

/**********Variables LCD***********/
volatile int DemoraLCD;
uint8_t bufferLCD[TOPE_BUFFER_LCD];
uint8_t msg[20];
uint8_t ptrLecturaLCD = 0;
uint8_t ptrEscrituraLCD = 0;
volatile uint8_t Eventos;

/**********Variables Dht11***********/
volatile uint8_t START_FLAG = 0;		//!< Se pone en 1 si se envio la señal de START
volatile uint8_t ESPERA_FLAG = 0;		//!< Se pone en 1 cuando ya pasó el tiempo establecido por el match 2 TIEMPO_DE_ESPERA 30ms
volatile uint8_t PULSOS_FLAG = 0;		//!< La bandera me dice que comenzo la rutina de interrumpir cada 20ns
volatile uint8_t PASO_ESPERA = 0;
volatile uint8_t PASO_START = 0;
volatile uint8_t buffer_entrada[MAX_BUFFER];
volatile uint8_t count_respuesta = 0;
volatile uint8_t count_bytes = 0;
volatile uint8_t	count_bits = 0;
volatile uint8_t trasmision_FLAG = 0;
volatile uint32_t count = 0;
volatile uint8_t flanco_FLAG = 0;
volatile uint8_t Buffer_lleno = 0;
volatile uint32_t capturaT1Ch1 = 0;				//!< Variables que guarda captura


uint8_t entero_ascii[6];


volatile uint16_t contador = 0;
volatile uint8_t i = 0;
int main(void) {
	InicializarKit();
    DisplayLCD("Arturo Manda",0,3);	// mensaje,renglon,offset
    DisplayLCD("Contador: ",1,0);		// mensaje,renglon,offset
    while(1) {
    	Aplicacion();
     }
    return 0 ;
}
