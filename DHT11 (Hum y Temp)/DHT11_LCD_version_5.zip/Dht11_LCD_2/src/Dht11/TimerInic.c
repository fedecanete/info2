#include "Aplicacion.h"

/**
 * Variables globales utilizadas por las Interrupciones
 */
extern volatile uint8_t START_FLAG;
extern volatile uint8_t buffer_entrada[];
extern volatile uint8_t count_bytes;
extern volatile uint8_t	count_bits;
extern volatile uint8_t Buffer_lleno;
extern volatile uint8_t ESPERA_FLAG;
extern volatile uint8_t PASO_START;
extern volatile uint32_t capturaT1Ch1[];				//!< Variables que guarda captura

extern volatile uint8_t paso_datos;

/**
 * Funcion: El timer 0 va a trabajar como match ante ciertos tiempos establecidos como TIEMPO_UN_PULSO --> cada 20ns
 * 			y tambien para el tiempo de start para la comunicacion TIEMPO_START
 *
 */
void InicTimer0(void){

	PCONP		|= ALIMENTA_T0;		//!< Habilitar Timer 0
	PCLKSEL0 	|= PCLK_T0;			//!< Clock for timer PCLK = CCLK Selecciono clock
	T0PR 		= PREESCALER;		//!< Configura presscaler para generar un pulso para contar por micro segundo
	T0MCR		&= CLEAR_MCR0;		//!< Limpio el MCR
	T0MCR 		|= MR0I_ENABLE;		//!< Habilito la interrupcion del MATCH0
	//T0MCR 		|= MR1I_ENABLE;		//!< Habilito la interrupcion del MATCH1
	T0MCR 		|= MR0_STOP;		//!< Detengo el timer con MATCH0
	//T0MCR 		|= MR1_STOP;		//!< Detengo el timer con MATCH1
	T0MR0		= START_TIME;
	T0MR1		= ESPERA_TIME;
	ISER0 		|= INT_TO_EN;  		//!< Habilito Interrupcion TIMER0
	T0TCR 		&= CLEAR_RST_EN;	//!< Limpio bits de control de reset y encendido del timer
	T0TCR 		|= TIMER_OFFyRST;	//!< Apago y reseteo el temporizador
	T0TCR 		&= TIMER_RST_OFF;	//!< Limpio bit de control de reset
//	T0TCR 		|= TIMER_ON;		//!< Enciendo timer0
}

/**
 * Funcion: El timer 1 va a trabajar en el modo de Captura con el puerto P1.18 Cap1.0
 */
void InicTimer1(void){
	SetPINSEL(EXPANSION15,PINSEL_FUNC3);//!< SW13 P1.18 como CAP1.0
	PCONP		|= ALIMENTA_T1;			//!< Habilitar Timer 1
	PCLKSEL0 	|= PCLK_T1;				//!< Clock for timer PCLK = CCLK Selecciono clock
	T1PR		= PREESCALER;			//!< Configura presscaler para generar un pulso para contar por micro segundo
	T1CTCR 		&= TIMER_CAPT1;			//!< contador de pulsos de CCLK
	T1CCR		&= RESET_CAPT1;			//!< Pone en cero los bits de control del CAP1.0
	T1CCR		|= CAPT1_INT_FE_RE;		//!< Habilito la interupcion ya sea por FE o por RE
	ISER0 		|= INT_T1_EN;  			//!< Habilito Interrupcion TIMER1
	T1TCR 		&= CLEAR_RST_EN;		//!< Limpio bits de control de reset y encendido del timer
	T1TCR 		|= TIMER_OFFyRST;		//!< Apago y reseteo el temporizador
	T1TCR 		&= TIMER_RST_OFF;		//!< Limpio bit de control de reset
	T1TCR 		|= TIMER_ON;			//!< Enciendo timer1
}


void TIMER1_IRQHandler (void){
	int estado = 0;
	estado = GetPIN(EXPANSION15);
	/**
	 * Si interrumpio por flanco, no importa cual sea, del CR0
	 */
	if(T1IR & CR0)
	{
		T1IR |= CR0; 						//!< Borro flag del captura 0
		/**
		 * Si el flanco es descendente se almacena el valor del timer
		 */
		if(!estado){
			capturaT1Ch1[paso_datos] = T1CR0;					//!< Leo valor de captura T0 Ch0

			paso_datos++;

		}
			/**
			 * Si el flanco es ascendente se limpia la cuenta del timer counter 1
			 */
			T1TCR 		&= CLEAR_RST_EN;		//!< Limpio bits de control de reset y encendido del timer
			T1TCR 		|= TIMER_OFFyRST;		//!< Apago y reseteo el temporizador
			T1TCR 		&= TIMER_RST_OFF;		//!< Limpio bit de control de reset
			T1TCR 		|= TIMER_ON;			//!< Enciendo timer1

	}
}

/**
 * Funcion: Si pasa el tiempo de START y ESPERA llega a la IRQ handler del timer 0
 *
 */
void TIMER0_IRQHandler (void){
	/**
	 * Ya paso el tiempo de start
	 */
	if(T0IR & MR0)
	{
		T0IR |= MR0; 				//!< Borro flag del captura 0
		T0MCR &= MR0_CLEAN;			//!< Deshabilito las opciones del match0
		PASO_START = 1;
	}
	/**
	 * Ya pasó el tiempo de espera
	 */
	if(T0IR & MR1){
		T0IR |= MR1;
		T0MCR &= MR1_CLEAN ;		//!<  Deshabilito las opciones del match1
		SetPINSEL(EXPANSION15,PINSEL_FUNC3);	//!< P1.18 como CAP1.0
	}
	T0TCR 		|= TIMER_OFFyRST;		//!< Apago y reseteo el temporizador
}
