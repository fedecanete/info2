#include "Aplicacion.h"


/**
 * Variables globales para Aplicacion.c
 */
extern volatile uint8_t START_FLAG;
extern volatile uint8_t PASO_START;
extern volatile uint8_t ESPERA_FLAG;
extern volatile uint8_t PASO_MINUTO;
/**
 * Variables globales para Proceso_lectura
 */
extern volatile uint8_t buffer_entrada[];
extern volatile uint8_t count_bytes;
extern volatile uint8_t	count_bits;
extern volatile uint32_t count;
extern volatile uint8_t START_FLAG;
extern volatile uint8_t Buffer_lleno;
extern volatile uint32_t capturaT1Ch1[];				//!< Variables que guarda captura
extern volatile uint8_t RH_entero;
extern volatile uint8_t RH_decimal;
extern volatile uint8_t Temp_entero;
extern volatile uint8_t Temp_decimal;
extern volatile uint8_t Checksum;
//extern volatile uint8_t valor[];
extern volatile uint8_t paso_datos;

void Aplicacion(){
	int i= 0;
	int valor[TRASMISION_MAX];
	if(!START_FLAG && !ESPERA_FLAG){
		START_FLAG = 1;
		/**
		 * Seteo al pin P1.18 como GPIO para mandar señal de START 18ms y ESPERA
		 */
		SetPINSEL(EXPANSION15,PINSEL_GPIO);
		SetDIR(EXPANSION15,SALIDA);
		SetMODE_OD(EXPANSION15,OPEN_DRAIN);
		T0TCR 		&= CLEAR_RST_EN;		//!< Limpio bits de control de reset y encendido del timer
		T0TCR 		|= TIMER_OFFyRST;		//!< Apago y reseteo el temporizador
		T0TCR 		&= TIMER_RST_OFF;		//!< Limpio bit de control de reset
		T0MCR 		|= MR0I_ENABLE;		//!< Habilito la interrupcion del MATCH0
		T0MCR 		|= MR0_STOP;		//!< Detengo el timer con MATCH0
		T0MCR &= MR1_CLEAN ;		//!<  Deshabilito las opciones del match1
		PULSO_START;
		T0TCR 		|= TIMER_ON;			//!< Enciendo timer1
	}
	if(START_FLAG && !ESPERA_FLAG && PASO_START){
		ESPERA_FLAG=1;
		T0TCR 		&= CLEAR_RST_EN;		//!< Limpio bits de control de reset y encendido del timer
		T0TCR 		|= TIMER_OFFyRST;		//!< Apago y reseteo el temporizador
		T0TCR 		&= TIMER_RST_OFF;		//!< Limpio bit de control de reset
		T0MCR 		|= MR1I_ENABLE;		//!< Habilito la interrupcion del MATCH1
		T0MCR 		|= MR1_STOP;		//!< Detengo el timer con MATCH1
		PULSO_ESPERA;
		T0TCR 		|= TIMER_ON;			//!< Enciendo timer1
	}
	if(PASO_MINUTO){
		PASO_MINUTO = 0;
		ESPERA_FLAG = 0;
		START_FLAG = 0;
		PASO_START = 0;
		T0MCR &= MR0_CLEAN;				//!< Deshabilito las opciones del match0
		T0MCR &= MR1_CLEAN ;			//!<  Deshabilito las opciones del match1
	}
	if(paso_datos == TRASMISION_MAX){
		Proceso_lectura();
		for(i = 0; i<TRASMISION_MAX; i++){
			valor[i] = capturaT1Ch1[i];
		}
		muestreo();
		paso_datos = 0;
		Buffer_lleno = 0;
	}
}

void Proceso_lectura(){
	int cont = 0;
	for(cont = 1; cont < TRASMISION_MAX; cont ++){ //porque capturaT1CH1[0] vale 80us de preparacion
		/**
		 * Caso para tomar la informacion como "1"
		 */
		if((capturaT1Ch1[cont] > 30)&&(capturaT1Ch1[cont] < 80)){

			buffer_entrada[count_bytes] |= 1<<(count_bits-1);		//!< almaceno el 1 en la posicion del bit para el buffer
			count_bits--;
		}
		/**
		 * Caso para tomar la informacion como "0"
		 */
		if((capturaT1Ch1[cont] > 0)&&(capturaT1Ch1[cont] < 30)){

			buffer_entrada[count_bytes] &= ~(1<<(count_bits-1)); 	//!< almaceno el 0 en la posicion del bit para el buffer
			count_bits--;
		}

		if(count_bits == 0){
			count_bits = 8;
			count_bytes++;
		}
		if(count_bytes == MAX_BUFFER){			//!< 40 bits de datos ---> 5 bytes trasmitidos
			count_bytes = 0;
			count_bits = 8;
			Buffer_lleno = 1; 					//!< Flag que avisa que el buffer esta completo para muestrear
			RH_entero = buffer_entrada[0];
			RH_decimal = buffer_entrada[1];
			Temp_entero = buffer_entrada[2];
			Temp_decimal = buffer_entrada[3];
			Checksum = buffer_entrada[4];
		}
	}
}

extern volatile uint8_t entero_ascii[6];

void muestreo(){
	if(( RH_entero + RH_decimal + Temp_entero + Temp_decimal ) == Checksum){
		Conversor( Temp_entero);
		DisplayLCD(entero_ascii,0,6);
		DisplayLCD(",",0,9);
		Conversor(Temp_decimal);
		DisplayLCD(entero_ascii,0,10);

		Conversor(RH_entero);
		DisplayLCD(entero_ascii,1,6);
		DisplayLCD(",",1,9);
		Conversor(RH_decimal);
		DisplayLCD(entero_ascii,1,10);
	}


}
