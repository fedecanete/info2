#include "Aplicacion.h"

extern volatile int DemoraLCD;
extern volatile uint16_t contador;
extern uint8_t entero_ascii[];

#define MINUTO 24000
extern volatile uint8_t PASO_MINUTO;
extern volatile uint32_t cuenta_minuto;
void SysTick_Handler(void) {

	Dato_LCD();
	if ( Demora_LCD )
		Demora_LCD--;

	contador++;
/**
 * Rutina para que titile el cursor
 */
	if ((contador == 300)){
	    DisplayLCD(":",0,4);		// mensaje,renglon,offset
	    DisplayLCD(":",1,3);		// mensaje,renglon,offset
	}else if(contador == 700){
		DisplayLCD(" ",0,4);		// mensaje,renglon,offset
		DisplayLCD(" ",1,3);		// mensaje,renglon,offset
		contador = 0;
	}
	/**
	 * Cada 5 minutos actualiza la humedad y temperatura
	 */
	cuenta_minuto++;
	if(cuenta_minuto == (5*MINUTO)){
		PASO_MINUTO = 1;
		cuenta_minuto = 0;
	}

}
