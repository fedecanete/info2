#include "FW_GPIO.h"
#include "Oscilador.h"
#include "RegsLPC1769.h"
#include "LCD.h"
#include "Kit.h"

void InicializarKit(void);
void InicSysTick(void);
void Proceso_lectura(void);
void Aplicacion(void);
void muestreo(void);

