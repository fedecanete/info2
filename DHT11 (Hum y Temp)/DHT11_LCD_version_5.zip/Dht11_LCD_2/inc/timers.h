
/**
 * Tiempos
 */
#define START_TIME 18000 	//!< 18ms
#define ESPERA_TIME 30	//!< 30us

/* Tamaño del buffer debido a los 40 bits que se van a recibir del DHT11 */
#define MAX_BUFFER	5
#define TRASMISION_MAX 41

#define  	CAP1_0	PORT1,0
#define		P3_26	PORT3,26
/*DEFINES UTILIZADOS EN LA FUNCION START*/
#define	PULSO				1
#define PULSO_DOWN 			0
#define PULSO_ESPERA		SetPIN(EXPANSION15,PULSO)
#define PULSO_START			SetPIN(EXPANSION15,PULSO_DOWN)

//!< Timers
//!< Timer 0
	#define		TIMER0 		( ( __RW uint32_t  * ) 0x40004000UL )
	#define		T0IR		TIMER0[0]
	#define		T0TCR		TIMER0[1]
	#define		T0TC		TIMER0[2]
	#define		T0PR		TIMER0[3]
	#define		T0PC		TIMER0[4]
	#define		T0MCR		TIMER0[5]
	#define		T0MR0		TIMER0[6]
	#define		T0MR1		TIMER0[7]
	#define		T0MR2		TIMER0[8]
	#define		T0MR3		TIMER0[9]
	#define		T0CCR		TIMER0[10]
	#define		T0CR0		TIMER0[11]
	#define		T0CR1		TIMER0[12]

	#define		_T0EMR	( ( __RW uint32_t  * ) 0x4000403CUL )
	#define		T0EMR	_T0EMR[0]

	#define		_T0CTCR	( ( __RW uint32_t  * ) 0x40004070UL )
	#define		T0CTCR	_T0CTCR[0]

	//!< Timer 1
	#define		TIMER1 		( ( __RW uint32_t  * ) 0x40008000UL )
	#define		T1IR		TIMER1[0]
	#define		T1TCR		TIMER1[1]
	#define		T1TC		TIMER1[2]
	#define		T1PR		TIMER1[3]
	#define		T1PC		TIMER1[4]
	#define		T1MCR		TIMER1[5]
	#define		T1MR0		TIMER1[6]
	#define		T1MR1		TIMER1[7]
	#define		T1MR2		TIMER1[8]
	#define		T1MR3		TIMER1[9]
	#define		T1CCR		TIMER1[10]
	#define		T1CR0		TIMER1[11]
	#define		T1CR1		TIMER1[12]

	#define		_T1EMR	( ( __RW uint32_t  * ) 0x4000803CUL )
	#define		T1EMR	_T1EMR[0]

	#define		_T1CTCR	( ( __RW uint32_t  * ) 0x40008070UL )
	#define		T1CTCR	_T1CTCR[0]

/*Defines para la configuracion de capturas del puerto P1.18 CAP1.0*/
	#define 	ALIMENTA_T1			0x00000004
	#define 	PCLK_T1				0x00000010
	#define		INT_T1_EN			0x00000004
	#define 	CLR_T0IR			0x40

	//!< Timer 2
	#define		TIMER2 		( ( __RW uint32_t  * ) 0x40090000UL )
	#define		T2IR		TIMER2[0]
	#define		T2TCR		TIMER2[1]
	#define		T2TC		TIMER2[2]
	#define		T2PR		TIMER2[3]
	#define		T2PC		TIMER2[4]
	#define		T2MCR		TIMER2[5]
	#define		T2MR0		TIMER2[6]
	#define		T2MR1		TIMER2[7]
	#define		T2MR2		TIMER2[8]
	#define		T2MR3		TIMER2[9]
	#define		T2CCR		TIMER2[10]
	#define		T2CR0		TIMER2[11]
	#define		T2CR1		TIMER2[12]

	#define		_T2EMR	( ( __RW uint32_t  * ) 0x4009003CUL )
	#define		T2EMR	_T2EMR[0]

	#define		_T2CTCR	( ( __RW uint32_t  * ) 0x40090070UL )
	#define		T2CTCR	_T2CTCR[0]

	//!< Timer 3
	#define		TIMER3 		( ( __RW uint32_t  * ) 0x40094000UL )
	#define		T3IR		TIMER3[0]
	#define		T3TCR		TIMER3[1]
	#define		T3TC		TIMER3[2]
	#define		T3PR		TIMER3[3]
	#define		T3PC		TIMER3[4]
	#define		T3MCR		TIMER3[5]
	#define		T3MR0		TIMER3[6]
	#define		T3MR1		TIMER3[7]
	#define		T3MR2		TIMER3[8]
	#define		T3MR3		TIMER3[9]
	#define		T3CCR		TIMER3[10]
	#define		T3CR0		TIMER3[11]
	#define		T3CR1		TIMER3[12]

	#define		_T3EMR	( ( __RW uint32_t  * ) 0x4009403CUL )
	#define		T3EMR	_T3EMR[0]

	#define		_T3CTCR	( ( __RW uint32_t  * ) 0x40094070UL )
	#define		T3CTCR	_T3CTCR[0]

	#define ALIMENTA_T0			0x00000002
	#define PCLK_T0				0x00000004
	#define PREESCALER			100
	#define MR0					1
	#define MR1					2
	#define MR2					4
	#define	TIMER_MODE			0xFFFFFFFC
	#define RESET_CAPT0			0xFFFFFFF8
	#define CAPT0_INT_FE		0x00000006
	#define INT_TO_EN			0x00000002
	#define CLEAR_RST_EN		0xFFFFFFFC
	#define TIMER_OFFyRST		0x00000002
	#define TIMER_RST_OFF		0xFFFFFFFD
	#define TIMER_ON			0x00000001
	#define TIMER_OFF			0xFFFFFFFC
	#define MATCH00				3
	#define MATCH01				6
	#define TIMER				0xFFFFFFFC
	#define TIMER_COUNTER_CLR	0xFFFFFFF0
	#define CLEAR_MCR0		 	0xFFFFF000
/**
 * Configuraciones del match0
 */
	#define	MR0I_ENABLE			0x00000001
	#define	MR0I_DISABLE		0xFFFFFFFE
	#define MR0_CLEAN 			0xFFFFFFF8
	#define	MR0_STOP			0x00000004
	#define MR0_RESET			0x00000002

/**
 * Configuraciones del match1
 */

	#define	MR1_STOP			0x00000020
	#define MR1_RESET			0x00000010
	#define MR1_CLEAN 			0xFFFFFFC7
	#define MR1I_ENABLE			0x00000008
	#define	MR1I_DISABLE		0xFFFFFFF7

/**
 * Configuraciones del match2
 */

	#define MR2I_ENABLE			0x00000040
	#define	MR2I_DISABLE		0xFFFFFFBF
	#define	MR2_RESET			0x00000080
	#define MR2_STOP			0x00000100



/**
 * Timer0
 */
void InicTimer0(void);						//!< Inicializacion de timer
void InicTimer1(void);

#define	CR0					0x00000010
#define ALIMENTA_T0			0x00000002
#define PCLK_T0				0x00000004
#define PREESCALER			100
#define TIMER_CAPT0			0xFFFFFFF0
#define RESET_CAPT0			0xFFFFFFF8
#define CAPT0_INT_FE		0x00000006
#define INT_TO_EN			0x00000002
#define CLEAR_RST_EN		0xFFFFFFFC
#define TIMER_OFFyRST		0x00000002
#define TIMER_RST_OFF		0xFFFFFFFD
#define TIMER_ON			0x00000001
#define ALIMENTA_TIMER0		PCONP |= 0x00000002
#define	ELIGE_PCLK_T0		PCLKSEL0 |= 0x00000004
#define	CONFIG_PREESC_T0	T0PR = 100000000
#define	TIMER_CAPT00		T0CTCR &= 0xFFFFFFF0
#define	RST_CONFIG_CAP00	T0CCR &= 0xFFFFFFF8
#define	INT_FE_CAP00		T0CCR |= 0x00000006
#define	INT_TIMER0_EN		ISER0 |= 0x00000002
#define	RST_BITS_RSTyEN_T0 	T0TCR &= 0xFFFFFFFC
#define	TIMER0_OFFyRST		T0TCR |= 0x00000002
#define	RST_BITS_RST		T0TCR &= 0xFFFFFFFD
#define	TIMER0_ON			T0TCR |= 0x00000001

/**
 * Captura definiciones
 */

#define CAP0RE_ON	0x00000001
#define CAP0RE_OFF	0xFFFFFFFE
#define CAP0FE_ON	0x00000002
#define CAP0FE_OFF	0xFFFFFFFD
#define CAP0I_ON	0x00000004
#define CAP0I_OFF	0xFFFFFFFB

#define CAP1RE_ON	0x00000008
#define CAP1RE_OFF	0xFFFFFFF7
#define CAP1FE_ON	0x00000010
#define CAP1FE_OFF	0xFFFFFFEF
#define CAP1I_ON	0x00000020
#define CAP1I_OFF	0xFFFFFFDF

#define RESET_CAPT1		0xFFFFFFF8
#define CAPT1_INT_FE_RE	0x00000007
#define TIMER_CAPT1		0xFFFFFFF0
