/*
 * dac.h
 *
 *  Created on: 9 de oct. de 2016
 *      Author: Gabriel
 */

#ifndef INC_DAC_H_
#define INC_DAC_H_

void InicDac(void);
void disparaDAC(uint16_t);

#endif /* INC_DAC_H_ */
