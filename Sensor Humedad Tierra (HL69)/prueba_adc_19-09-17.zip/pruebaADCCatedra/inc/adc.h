/*
 * ADC.h
 *
 *  Created on: 29 de ago. de 2017
 *      Author: Arturo Burin
 */

#ifndef HEADERS_ADC_H_
#define HEADERS_ADC_H_

#define PCONP_ADC	12
#define PCLK_ADC	24
#define ISE_ADC		22
//Encender el modulo ADC
#define		ADC_ON		PCONP|=(1<<PCONP_ADC)
//divisor del clock del adc
#define 	DIVCLK_ADC	0

void InicADC(void);


//registro ADCR
typedef struct
	{
		union{
			__RW uint32_t _AD0CR;
			struct{
				__RW uint32_t _SEL:8;
				__RW uint32_t _CLKDIV:8;
				__RW uint32_t _BURST:1;
				__RW uint32_t _RESERVED0:4;
				__RW uint32_t _PDN:1;
				__RW uint32_t _RESERVED1:2;
				__RW uint32_t _START:2;
				__RW uint32_t _EDGE:1;
				__RW uint32_t _RESERVED2:4;
			}bits;
		};
		__RW uint32_t _AD0GDR;
	}adc_t;

#define		DIR_AD0CR 		( ( adc_t  * ) 0x40034000)
#define 	AD0CR		DIR_AD0CR->_AD0CR
	#define  	SEL		DIR_AD0CR->bits._SEL
	#define  	CLKDIV		DIR_AD0CR->bits._CLKDIV
	#define  	BURST		DIR_AD0CR->bits._BURST
	#define  	PDN			DIR_AD0CR->bits._PDN
	#define  	START		DIR_AD0CR->bits._START
	#define  	EDGE		DIR_AD0CR->bits._EDGE
#define  	AD0GDR			DIR_AD0CR->_AD0GDR
#define  	AD0INTEN		( (__RW uint32_t * ) 0x4003400C)
#define  	AD0STAT			( (__RW uint32_t * ) 0x40034030)




#endif /* HEADERS_ADC_H_ */
