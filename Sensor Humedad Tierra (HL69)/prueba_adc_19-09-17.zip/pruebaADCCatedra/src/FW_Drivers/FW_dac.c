/*
 * FW_dac.c
 *
 *  Created on: 9 de oct. de 2016
 *      Author: Gabriel
 */


/*
 * FW_adc.c
 *
 *  Created on: 21/10/2013
 *      Author: Gos
 */
#include "Aplicacion.h"


/**
 * void InicADC(void)
 *
 * Rutina de inicializacion del ADC
 * */
void InicDac(void){
	//Selecciono el clock del ADC como 25MHz:
	PCLKSEL0 &= ~(0x03<<22);
	//PINSEL
	SetPINSEL(DAC, PINSEL_FUNC2);
	//Consumo mpinimo, velocidad de refrezco 400kHz
	DACR |= (0x01<<16);
}

void disparaDAC(uint16_t valor){
	uint16_t aux = 0;
	aux = valor >> 2;
	DACR = (aux << 6);
	//Consumo mpinimo, velocidad de refrezco 400kHz
	DACR |= (0x01<<16);
}

