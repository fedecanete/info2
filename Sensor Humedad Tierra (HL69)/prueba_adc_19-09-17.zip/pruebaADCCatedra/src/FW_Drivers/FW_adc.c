/*
 * FW_adc.c
 *
 *  Created on: 21/10/2013
 *      Author: Gos
 */
#include "Aplicacion.h"

extern uint32_t resultadoADC;


/**
 * void InicADC(void)
 *
 * Rutina de inicializacion del ADC
 * */
void InicADC(void){
	//1.- Activo la alimentacion del dispositivo desde el registro PCONP:
	//PCONP |= 1<<12;
	ADC_ON;

	//2.- Selecciono el clock del ADC como 25MHz:
	//PCLKSEL0 &= ~(0x03<<24);
	PCLKSEL0 &= ~(3 << PCLK_ADC);
	PCLKSEL0 |= (DIVCLK_ADC << PCLK_ADC);

	//3.- Y el divisor como 1, para muestrear a 200kHz:
	ADCR |= 0x00000100;

	//ADC0.2 : P0[25]->PINSEL1: 19:18
	//PINSEL1 |= PINSEL_FUNC1 << 18;
	SetPINSEL (0,25,1);


	//9.- ACTIVO LAS INTERRUPCIONES GLOBALES Y ADC0CH2:
	ADINTEN &= 0xFFFFFF04;
	//10.- Selecciono que voy a tomar muestras del canal AD:
	ADCR |= 0x00000004;


	//4.- Configuro los pines del ADC0
	//ADC0.5 : P1[31]->PINSEL3: 30:31

	// PINSEL3 |= PINSEL_FUNC3 << 30;

	//5.- ACTIVO LAS INTERRUPCIONES GLOBALES Y ADC0CH5:

	//ADINTEN &= 0xFFFFFF20;

	// HABILITO INT DEL ADC EN NVIC
	ISER0 |= (0x01<<ISE_ADC);

	//6.- Selecciono que voy a tomar muestras del canal AD0.5:
	//ADCR |= 0x00000020;

	//7.- Activo el ADC (PDN = 1):
	//ADCR |= 1<<21;
	PDN = 1;

	//8.- Disparo el ADC para que muestree solo, con BURST = 1 y START = 000:
	ADCR &= ~(0x0F<<24);
	ADCR |= 1<<16;



}

/**
 * void ADC_IRQHandler(void)
 * */
void ADC_IRQHandler(void){
	static uint8_t contador = 0;
	static uint16_t resultadoParcial = 0;
	static uint32_t acumulador = 0;

	resultadoParcial = (ADGDR >> 4) & (0x0000FFFF);
	acumulador += resultadoParcial;
	contador ++;

	if(contador == 128){
		resultadoADC = acumulador >> 7;
		contador = 0;
		acumulador = 0;
	}

}
