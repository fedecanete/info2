#include "Aplicacion.h"

extern volatile int DemoraLCD;


void SysTick_Handler(void) {

	static volatile uint8_t decimas  = DECIMAS;
// Aquí escribo todo aquello que deseo que ocurra cada 2,5ms.

	BarridoDisplay();
	DriverTeclado();
	Debounce ();

	Dato_LCD();
	if ( Demora_LCD )
		Demora_LCD--;


	decimas-- ;
 	if( !decimas )	//pasaron 100ms
	{
		decimas = DECIMAS ;
		// Aquí escribo todo aquello que deseo que ocurra cada 100ms.
		AnalizarTimer();
	}

}
