/*
 * Aplicacion.c
 *
 *  Created on: 07/09/2013
 *      Author: marcelo
 */

#include "Aplicacion.h"

extern uint32_t resultadoADC;
extern uint8_t entero_ascii[];
extern uint8_t flagMuestraADC;

void aplicacionADC(void) {
	uint8_t tecla;

	TmrEvent();

	if(flagMuestraADC){
		Display(resultadoADC);
		disparaDAC(resultadoADC);
		Conversor(resultadoADC);
		DisplayLCD(entero_ascii, 1, 11);
		flagMuestraADC = 0;
	}

	/*
	tecla = Teclado();
	if(tecla != NO_KEY){
		Display (tecla%1000, DSP1); // Muestra tecla en dsilpay 1 (rojo)
		tecla = NO_KEY;
	}

	if(PUERTA_ABIERTA)
		Display(001,DSP0);
	if(PB)
		Display(002,DSP0);
	if(P1)
		Display(003,DSP0);
	if(P12)
		Display(004,DSP0);
	if(P2)
		Display(005,DSP0);
*/
}
