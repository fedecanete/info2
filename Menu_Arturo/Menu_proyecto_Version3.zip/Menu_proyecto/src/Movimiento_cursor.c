#include "Aplicacion.h"

/*****Prototipos*****/
void CursorAbajo(void);
void CursorArriba(void);
void Cursor_Menu_Lista(void);

/******Variables Globales******/
extern volatile uint8_t estados;
extern volatile	uint8_t cont;
extern volatile uint8_t arriba;
extern volatile uint8_t abajo;



void CursorAbajo(void){
	WComando8(LCD_CLEAR);	//Limpio el LCD
	WComando8(LCD_1POS0);	//Posiciono el cursor
	if(!cont){
		Escribir(" Programar_FyH");
		WComando8(LCD_2POS0);	//Posiciono el cursor
		Escribir(" Humedad_Tierr");
		WComando8(LCD_1POS0);
	}
	if(cont == 1){
		Escribir(" Programar_FyH");
		WComando8(LCD_2POS0);	//Posiciono el cursor
		Escribir(" Humedad_Tierr");
		WComando8(LCD_2POS0);
	}
	if(cont == 2){
		Escribir(" Humedad_Tierr");
		WComando8(LCD_2POS0);	//Posiciono el cursor
		Escribir(" Est. HyT Amb");
		WComando8(LCD_2POS0);
	}
	if(cont == 3){
		Escribir(" Est. HyT Amb");
		WComando8(LCD_2POS0);	//Posiciono el cursor
		Escribir(" Progr.Alarm");
		WComando8(LCD_2POS0);
	}
	if(cont == 4){
		Escribir(" Progr.Alarm");
		WComando8(LCD_2POS0);	//Posiciono el cursor
		Escribir(" Progr.H.Crit");
		WComando8(LCD_2POS0);
	}
	if(cont == 5){
		Escribir(" Progr.H.Crit");
		WComando8(LCD_2POS0);	//Posiciono el cursor
		Escribir(" Programar_FyH");
		WComando8(LCD_2POS0);
	}
}

void CursorArriba(void){
	WComando8(LCD_CLEAR);	//Limpio el LCD
	WComando8(LCD_1POS0);	//Posiciono el cursor
	if(!cont){
		Escribir(" Programar_FyH");
		WComando8(LCD_2POS0);	//Posiciono el cursor
		Escribir(" Humedad_Tierr");
	}
	if(cont == 1){
		Escribir(" Humedad_Tierr");
		WComando8(LCD_2POS0);	//Posiciono el cursor
		Escribir(" Est. HyT Amb");
	}
	if(cont == 2){
		Escribir(" Est. HyT Amb");
		WComando8(LCD_2POS0);	//Posiciono el cursor
		Escribir(" Progr.Alarm");
	}
	if(cont == 3){
		Escribir(" Progr.Alarm");
		WComando8(LCD_2POS0);	//Posiciono el cursor
		Escribir(" Progr.H.Crit");
	}
	if(cont == 4){
		Escribir(" Progr.H.Crit");
		WComando8(LCD_2POS0);	//Posiciono el cursor
		Escribir(" Programar_FyH");
	}
	WComando8(LCD_1POS0);
}

void Cursor_Menu_Lista(void){
	if(arriba){
		CursorArriba();
		arriba = 0;
	}
	if(abajo){
		CursorAbajo();
		abajo = 0;
	}
}

void Posicion_cursor(void){
	if(arriba){
		WComando8(LCD_1POS0);
		arriba = 0;
	}
	if(abajo){
		WComando8(LCD_2POS0);
		abajo = 0;
	}
}
