#include <string.h>
#include "Aplicacion.h"

volatile uint8_t msgDisplay[DIGITOS];			//!< Buffer del display
volatile uint8_t buffKey;						//!< Buffer del teclado
volatile uint16_t DemoraLCD;					//!< Demora LCD por Systick
volatile uint32_t contador_minuto=24000;
volatile uint8_t estados = REPOSO;
volatile uint8_t cont = 0;

/*****Flags de estados******/
volatile uint8_t entro_reposo = 0;			//!<Estado 0 REPOSO
volatile uint8_t entro_menu_lista = 0;		//!<Estado 1 MENU_LISTA
volatile uint8_t entro_estado_2 = 0;		//!<Estado 2 PROG_FyH
volatile uint8_t entro_estado_3 = 0;		//!<Estado 3 EST_H_TIE
volatile uint8_t entro_estado_4 = 0;		//!<Estado 4 PROGR_RIEGO
volatile uint8_t entro_estado_5 = 0;		//!<Estado 5 PROG_H_CRIT
volatile uint8_t entro_estado_6 = 0;		//!<Estado 6 EST_HyT_AMB
volatile uint8_t arriba = 0;
volatile uint8_t abajo = 0;

int main(void) {
	InicializarKit();
    while(1) {
    	Maquina();
    	Cursor_Menu();
    }
    return 0 ;
}
