#include "Aplicacion.h"

/******Variables Globales*******/
extern volatile uint8_t cont;
extern volatile uint8_t estados;
extern volatile uint8_t entro_reposo;
extern volatile uint8_t entro_menu_lista;
extern volatile uint8_t entro_estado_2;		//!<Estado 2 PROG_FyH
extern volatile uint8_t entro_estado_3;		//!<Estado 3 EST_H_TIE
extern volatile uint8_t entro_estado_4;		//!<Estado 4 PROGR_RIEGO
extern volatile uint8_t entro_estado_5;		//!<Estado 5 PROG_H_CRIT
extern volatile uint8_t entro_estado_6;		//!<Estado 6 EST_HyT_AMB
extern volatile uint8_t arriba;
extern volatile uint8_t abajo;


void Maquina (){
	switch(estados){
	case REPOSO:
			if(!entro_reposo){
				entro_reposo = 1;
				WComando8(LCD_CLEAR);
				WComando8(LCD_1POS0);
				Escribir("Bienvenidos!!!");
			}
		break;
	case MENU_LISTA:
		if(arriba || abajo){
			Cursor_Menu_Lista();
		}
		break;
	case PROG_FyH:
		if(entro_estado_2){
			entro_estado_2 = 0;
			WComando8(LCD_CLEAR);
			WComando8(LCD_1POS0);
			Escribir("Estado_2");
		}

		break;
	case EST_H_TIE:
		if(entro_estado_3){
			entro_estado_3 = 0;
			WComando8(LCD_CLEAR);
			WComando8(LCD_1POS0);
			Escribir("Estado_3");
		}

		break;
	case PROG_RIEGO:
		if(entro_estado_4){
			entro_estado_4 = 0;
			WComando8(LCD_CLEAR);
			WComando8(LCD_1POS0);
			Escribir("Estado_4");
		}

		break;
	case PROG_H_CRIT:
		if(entro_estado_5){
			entro_estado_5 = 0;
			WComando8(LCD_CLEAR);
			WComando8(LCD_1POS0);
			Escribir("Estado_5");
		}

		break;
	case EST_HyT_AMB:
		if(entro_estado_6){
			entro_estado_6 = 0;
			WComando8(LCD_CLEAR);
			WComando8(LCD_1POS0);
			Escribir("Estado_6");
		}

		break;
	default:
		break;

	}
}

void Cursor_Menu(void){
	switch(Teclado()){
	case SW1:				//Abajo
		if(!entro_menu_lista){
			entro_menu_lista = 1;
			estados = MENU_LISTA;
			WComando8(BLINK_ON);	//Activo el titileo del cursor
		}
		cont++;
		if(cont>MAX_LISTA){
			cont=0;
		}
		abajo = 1;
		break;
	case SW2:				//Arriba
		if(!entro_menu_lista){
			entro_menu_lista = 1;
			estados = MENU_LISTA;
			WComando8(BLINK_ON);	//Activo el titileo del cursor
		}
		cont--;
		if(cont == 255) cont=4;
		arriba = 1;
		break;
	case SW3:				//Enter sub menú
		Estados();
		cont = 0;
		entro_reposo = 0;
		entro_menu_lista = 0;
		break;
	case SW4:
		estados = REPOSO;
		cont = 0;
		entro_reposo = 0;
		entro_menu_lista = 0;
		break;
	case SW5:
		estados = REPOSO;
		cont = 0;
		entro_reposo = 0;
		entro_menu_lista = 0;
		break;

	default:

		break;
	}
}

void Estados (void){
	switch(cont){
	case (PROG_FyH-2):
			estados = PROG_FyH;
			entro_estado_2 = 1;
		break;
	case (EST_H_TIE-2):
			estados = EST_H_TIE;
			entro_estado_3 = 1;
		break;

	case (PROG_RIEGO-2):
			estados = PROG_RIEGO;
			entro_estado_4 = 1;
		break;

	case (PROG_H_CRIT-2):
			estados = PROG_H_CRIT;
			entro_estado_5 = 1;
		break;

	case (EST_HyT_AMB-2):
			estados = EST_HyT_AMB;
			entro_estado_6 = 1;
		break;
	default:
		break;
	}
}


