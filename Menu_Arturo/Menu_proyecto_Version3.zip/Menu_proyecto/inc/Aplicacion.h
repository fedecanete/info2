/*
 * Aplicacion.h
 *
 *  Created on: 14/06/2013
 *      Author: Marcelo
 */

#ifndef APLICACION_H_
#define APLICACION_H_

#include "RegsLPC1769.h"
#include "GPIO.h"
#include "Oscilador.h"
#include "KitInfo2_BaseBoard.h"
#include "LCD.h"
#include "Teclado_5x1.h"
#include "Display-Expansion2.h"

/**
 * Prototipo de funciones
 */
void Cursor_Menu(void);
void Maquina(void);
void Estados(void);
void Posicion_cursor(void);
uint8_t Teclado (void);

/**
 * Lista de opciones del Menu
 */
	#define		REPOSO			0
	#define		MENU_LISTA		1
	#define		PROG_FyH		2
	#define		EST_H_TIE		3
	#define		PROG_RIEGO		4
	#define		PROG_H_CRIT		5
	#define		EST_HyT_AMB		6

	#define MAX_LISTA 	5

//Defines de  Teclado combinado con LCD
#define 	T_SUMAR			1
#define 	T_RESTAR		2
#define 	T_OK 			3
#define 	T_DESPLAZAR		4
#define 	T_LOBBY			5


#endif /* APLICACION_H_ */
