#include "Aplicacion.h"

/******Variables Globales*******/
extern volatile uint8_t cont;

void Maquina (){
	switch(Teclado()){
	case 1:
		WComando8(BLINK_ON);	//Activo el titileo del cursor
		SetPIN (RGBB, ON);	//AZUL
		SetPIN (RGBG, OFF);
		SetPIN (RGBR, OFF);
		cont++;
		if(cont>MAX_LISTA){
			cont=0;
		}
		CursorAbajo();
		break;
	case 2:
		WComando8(BLINK_ON);	//Activo el titileo del cursor
		SetPIN (RGBB, OFF);	//VERDE
		SetPIN (RGBG, ON);
		SetPIN (RGBR, OFF);
		cont--;
		if(cont == 255) cont=5;
		CursorArriba();
		break;
	case 3:
		SetPIN (RGBB, ON);	//BLANCO
		SetPIN (RGBG, ON);
		SetPIN (RGBR, ON);
		break;
	case 4:
		SetPIN (RGBB, OFF);	//AMARILLO
		SetPIN (RGBG, ON);
		SetPIN (RGBR, ON);
		break;
	case 5:
		SetPIN (RGBB, ON);	//CELESTE
		SetPIN (RGBG, ON);
		SetPIN (RGBR, OFF);
		break;

	default:
		SetPIN (RGBB, OFF);	//APAGADO
		SetPIN (RGBG, OFF);
		SetPIN (RGBR, OFF);
		break;
	}
}
