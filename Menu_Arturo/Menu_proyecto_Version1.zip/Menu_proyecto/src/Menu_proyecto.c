#include <string.h>
#include "Aplicacion.h"

volatile uint8_t msgDisplay[DIGITOS];			//!< Buffer del display
volatile uint8_t buffKey;						//!< Buffer del teclado
volatile uint16_t DemoraLCD;					//!< Demora LCD por Systick
volatile uint32_t contador_minuto=24000;
volatile uint8_t estados = REPOSO;
volatile uint8_t array_estados[]={0,1,2,3,4,5,6};
volatile uint8_t cont = 0;


int main(void) {
	InicializarKit();
	WComando8(LCD_1POS0);
	Escribir("Bienvenidos!!!");
    while(1) {
    	Maquina();
    }
    return 0 ;
}
