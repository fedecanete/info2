#include "Aplicacion.h"

extern volatile uint16_t DemoraLCD;

void SysTick_Handler ( void );
extern volatile uint32_t contador_minuto;
void SysTick_Handler(void)

{

	DriverTeclado();
	if (DemoraLCD) DemoraLCD--;
	contador_minuto--;
	if(!contador_minuto){
		contador_minuto =24000;
	}
}
