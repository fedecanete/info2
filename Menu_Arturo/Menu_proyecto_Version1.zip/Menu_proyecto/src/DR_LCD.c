/**
 	\file FW_LCD.c
 	\brief Driver del LCD
 	\date 07.11.2017
*/

#include "Aplicacion.h"

/** \var extern volatile uint16_t DemoraLCD
*   \brief Variable descontada por interrupción (Systick)
*/

extern volatile uint16_t DemoraLCD;

/** \var extern volatile uint8_t flag_RiegoAut
*   \brief Flag de alarma del RTC
*/
extern volatile uint8_t flag_RiegoAut;

/** \var extern volatile uint8_t flag_IntMinutos
*   \brief Flag levantadado por incremento del contador minutos del RTC
*/
extern volatile uint8_t flag_IntMinutos;

/**
*	\fn void LCDDelay(uint16_t demora)
*	\brief Le da tiempo al LCD ya que procesa más lento que el MCU
*/

void LCDDelay(uint16_t demora)
{
	DemoraLCD = demora;
	while(DemoraLCD);
}

/**
*	\fn void LatchLcd(void)
*	\brief LCD Chip enable signal
*	\details Enciende el pin E del LCD (en modo Write) y se vuelve a encender.
*			Se usa cada vez que se escribe un nuevo comando en el LCD.
*/

void LatchLcd(void)
{
	SetPIN(LCD_E,ON);
	LCDDelay(2);
	SetPIN(LCD_E,OFF);
}

void Escribir (char *p) {
	//static uint8_t* aux=p;
	while(*p != '\0') {
		WDato(*p++);
	}
}

void WComando8(uint8_t comando)
{
	SetPIN(LCD_RS,OFF);
	// Parte Alta del comando
	SetPIN(LCD_D4,((comando & 0x10) >> 4));
	SetPIN(LCD_D5,((comando & 0x20) >> 5));
	SetPIN(LCD_D6,((comando & 0x40) >> 6));
	SetPIN(LCD_D7,((comando & 0x80) >> 7));
	LatchLcd();
	LCDDelay(2);

	// Parte Baja del comando
	SetPIN(LCD_D4,(comando & 0x01));
	SetPIN(LCD_D5,((comando & 0x02) >> 1));
	SetPIN(LCD_D6,((comando & 0x04) >> 2));
	SetPIN(LCD_D7,((comando & 0x08) >> 3));
	LatchLcd();
	LCDDelay(2);
}

void WComando4(uint8_t comando)
{
	SetPIN(LCD_RS,OFF);
	SetPIN(LCD_D4,((comando & 0x10) >> 4));
	SetPIN(LCD_D5,((comando & 0x20) >> 5));
	SetPIN(LCD_D6,((comando & 0x40) >> 6));
	SetPIN(LCD_D7,((comando & 0x80) >> 7));

	LatchLcd();
	LCDDelay(2);
}

void WDato (uint8_t dato)
{
	SetPIN(LCD_RS,ON);
	// Parte Alta del comando
	SetPIN(LCD_D4,((dato & 0x10) >> 4));
	SetPIN(LCD_D5,((dato & 0x20) >> 5));
	SetPIN(LCD_D6,((dato & 0x40) >> 6));
	SetPIN(LCD_D7,((dato & 0x80) >> 7));
	LatchLcd();
	LCDDelay(2);

	// Parte Baja del comando
	SetPIN(LCD_D4,(dato & 0x01));
	SetPIN(LCD_D5,((dato & 0x02) >> 1));
	SetPIN(LCD_D6,((dato & 0x04) >> 2));
	SetPIN(LCD_D7,((dato & 0x08) >> 3));
	LatchLcd();
	LCDDelay(2);
}
