#include "Aplicacion.h"

/******Variables Globales*******/
extern volatile uint8_t cont;

void Maquina (){
	switch(Teclado()){
	case 1:
		WComando8(BLINK_ON);	//Activo el titileo del cursor
		cont++;
		if(cont>MAX_LISTA){
			cont=0;
		}
		CursorAbajo();
		break;
	case 2:
		WComando8(BLINK_ON);	//Activo el titileo del cursor
		cont--;
		if(cont == 255) cont=5;
		CursorArriba();
		break;
	case 3:

		break;
	case 4:

		break;
	case 5:

		break;

	default:

		break;
	}
}
